const { onRequest } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { getFirestore } = require("firebase-admin/firestore");
const { createOpsSlackEvents } = require("./opsSlackEvents.cjs");
const { createInboxTrigger, recordTriggerFailure } = require("./opsSlackTrigger.cjs");
const { getAuth } = require("firebase-admin/auth");
const { createOpsMonitoring } = require("./opsMonitoring.cjs");
const { getApps, initializeApp } = require("firebase-admin/app");

// Admin via ADC (Application Default Credentials)
if (!getApps().length) {
  const projectId =
    process.env.GCLOUD_PROJECT ||
    process.env.GOOGLE_CLOUD_PROJECT ||
    "magmo-ac10c";
  const databaseURL = String(
    process.env.FIREBASE_DATABASE_URL ||
      process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL ||
      `https://${projectId}-default-rtdb.firebaseio.com`
  ).replace(/\/+$/, "");
  initializeApp({
    projectId,
    databaseURL,
    storageBucket:
      process.env.FIREBASE_STORAGE_BUCKET || `${projectId}.appspot.com`,
  });
}

let preparedHandler;
function getNextHandler() {
  if (!preparedHandler) {
    const app = require("next")({ dev: false, conf: { distDir: ".next" } });
    preparedHandler = app.prepare().then(() => app.getRequestHandler());
  }
  return preparedHandler;
}
const slackEvents = createOpsSlackEvents({ db: getFirestore() });
const opsMonitoring = createOpsMonitoring({ db: getFirestore(), auth: getAuth() });

const runtimeOptions = {
  // Firestore is in Los Angeles (us-west2); keeping SSR/API compute beside it
  // avoids cross-region latency and transfer for Admin SDK traffic.
  region: "us-west2",
  memory: "2GiB",
  timeoutSeconds: 540,
  minInstances: 0,
  maxInstances: 10,
  concurrency: 40,
};

async function handleNextRequest(req, res) {
  try {
    if (String(req.path || req.url || "").split("?")[0].replace(/\/+$/, "") === "/api/ops/monitoring") {
      return opsMonitoring.handleRequest(req, res);
    }
    if (String(req.path || req.url || "").split("?")[0].replace(/\/+$/, "") === "/api/slack/events") {
      return slackEvents.handleRequest(req, res);
    }
    const handle = await getNextHandler();
    return handle(req, res);
  } catch (error) {
    console.error("Error handling request:", error);
    res.status(500).send("Internal Server Error");
  }
}

// These functions are deployed independently so a test release cannot replace
// the production server that serves magmo.cloud.
exports.nextServerWest = onRequest(runtimeOptions, handleNextRequest);
exports.nextServerTestWest = onRequest(runtimeOptions, handleNextRequest);

// Evidence-only delivery. These functions cannot create Slack posts or execute
// work-order commands. The periodic sweep recovers interrupted/failed workers.
exports.opsSlackEventWorker = onDocumentCreated({
  region: "us-west2", document: "opsSlackEventInbox/{eventId}",
  memory: "512MiB", timeoutSeconds: 540, maxInstances: 4, concurrency: 1,
  retry: true,
}, createInboxTrigger({ processEvent: slackEvents.processEvent, recordFailure: error => recordTriggerFailure(getFirestore(), error) }));

exports.opsSlackEventRetrySweep = onSchedule({
  region: "us-west2", schedule: "every 1 minutes", timeZone: "UTC",
  memory: "512MiB", timeoutSeconds: 540, maxInstances: 1, retryCount: 0,
}, async () => slackEvents.sweep({ limit: 20 }));

// Optional reviews are deliberately isolated from live ingest and its leases.
exports.opsAstraReviewSweep = onSchedule({
  region: "us-west2", schedule: "every 1 minutes", timeZone: "UTC",
  memory: "512MiB", timeoutSeconds: 240, maxInstances: 1, concurrency: 1, retryCount: 0,
}, async () => require("./opsAstraQueue.cjs").sweepAstraJobs({ db: getFirestore(), limit: 2 }));

exports.trailerSlackMonitorSchedule = onSchedule(
  {
    region: "us-central1",
    schedule: "0 7,17 * * *",
    timeZone: "America/Los_Angeles",
    memory: "512MiB",
    timeoutSeconds: 540,
    retryCount: 2,
  },
  async () => {
    const secret = String(
      process.env.TRAILER_MONITOR_SECRET ||
        process.env.OPS_INGEST_SECRET ||
        process.env.CRON_SECRET ||
        ""
    ).trim();
    if (!secret) {
      throw new Error("Trailer monitor scheduler is missing its shared secret.");
    }
    const endpoint = String(
      process.env.TRAILER_MONITOR_URL ||
        "https://magmo-ac10c.web.app/api/cron/trailer-slack-monitor"
    ).trim();
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-ops-ingest-secret": secret,
      },
      body: JSON.stringify({ trigger: "firebase-schedule" }),
      signal: AbortSignal.timeout(520000),
    });
    const body = await response.text();
    if (!response.ok) {
      throw new Error(
        `Trailer monitor endpoint returned HTTP ${response.status}: ${body.slice(0, 1200)}`
      );
    }
    console.log("[TrailerSlackMonitorSchedule]", body.slice(0, 4000));
  }
);

exports.magmonitorAlertsSchedule = onSchedule(
  {
    region: "us-west2",
    schedule: "*/30 * * * *",
    timeZone: "America/Los_Angeles",
    memory: "512MiB",
    timeoutSeconds: 300,
    retryCount: 2,
    maxInstances: 1,
  },
  async () => {
    const secret = String(
      process.env.MAGMONITOR_ALERTS_SECRET ||
        process.env.CRON_SECRET ||
        process.env.OPS_INGEST_SECRET ||
        ""
    ).trim();
    if (!secret) {
      throw new Error("Magmonitor alert scheduler is missing its shared secret.");
    }
    const endpoint = String(
      process.env.MAGMONITOR_ALERTS_URL ||
        "https://magmo.cloud/api/cron/magmonitor-alerts"
    ).trim();
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-magmonitor-alerts-secret": secret,
      },
      body: JSON.stringify({ trigger: "firebase-schedule" }),
      signal: AbortSignal.timeout(280000),
    });
    const body = await response.text();
    if (!response.ok) {
      throw new Error(
        `Magmonitor alert endpoint returned HTTP ${response.status}: ${body.slice(0, 1200)}`
      );
    }
    console.log("[MagmonitorAlertsSchedule]", body.slice(0, 4000));
  }
);
