"use strict";

// The production package copies the pure contract alongside this runtime file.
// Local Next/tests use the source module; no network or credentials are read at import.
const contract = require("./opsSlackEventContract.cjs");
const { createOpsSlackInbox } = require("./opsSlackInbox.cjs");
const { createOpsSlackHelp } = require("./opsSlackHelp.cjs");

function describeOpsSlackEvents(env = process.env) {
  const mode = ["shadow", "active"].includes(env.OPS_SLACK_EVENTS_MODE)
    ? env.OPS_SLACK_EVENTS_MODE : "disabled";
  return {
    version: "2026-09-22.1",
    mode,
    configured: Boolean(env.SLACK_SIGNING_SECRET &&
      env.OPS_SLACK_EVENTS_TEAM_ID && env.OPS_SLACK_EVENTS_APP_ID),
    channelId: "C07EPLKV9JT",
    transport: "signed_http_events_durable_inbox",
    commandOwner: "python",
    pollingBackup: true,
    excludesClosedOnly: true,
    createsSlackPosts: false,
    dmHelpReplies: true,
    unmatchedThreadState: "needs_link",
    receiptSyncGraceSeconds: 300,
    processingAttribution: true,
  };
}

function createOpsSlackEvents({ db, env = process.env, fetch, now } = {}) {
  const inbox = createOpsSlackInbox({ db, env, fetch, now });
  const help = createOpsSlackHelp({ db, env, fetch, now });
  async function handleRequest(req, res) {
    res.setHeader("Cache-Control", "no-store");
    if (req.method !== "POST") {
      res.setHeader("Allow", "POST");
      return res.status(405).json({ ok: false, code: "method_not_allowed" });
    }
    try {
      const rawBody = req.rawBody;
      if (!Buffer.isBuffer(rawBody) && typeof rawBody !== "string") {
        return res.status(400).json({ ok: false, code: "raw_body_required" });
      }
      const event = contract.parseSlackEventRequest({
        rawBody,
        headers: req.headers,
        config: {
          signingSecret: env.SLACK_SIGNING_SECRET,
          teamId: env.OPS_SLACK_EVENTS_TEAM_ID,
          appId: env.OPS_SLACK_EVENTS_APP_ID,
          channelId: "C07EPLKV9JT",
        },
        nowMs: now ? now() : Date.now(),
      });
      if (event.kind === "challenge") return res.status(200).json({ challenge: event.challenge });
      if (event.kind === "help") {
        const result = await help.reply(event);
        return res.status(200).json({ ok: true, ...result });
      }
      if (event.kind !== "message") {
        return res.status(200).json({ ok: true, ignored: true, reason: event.reason || event.kind });
      }
      if (describeOpsSlackEvents(env).mode === "disabled") {
        // Do not acknowledge evidence while disabled: Slack may retry after activation.
        return res.status(503).json({ ok: false, code: "event_inbox_disabled", retryable: true });
      }
      // This is the only awaited work on the Slack acknowledgement path.
      // AI runs in the Firestore worker, never as an unawaited HTTP background task.
      const result = await inbox.receiveNormalized(event);
      return res.status(200).json({ ok: true, eventId: event.eventId, duplicate: Boolean(result.duplicate) });
    } catch (error) {
      const code = /^[a-z0-9_]{1,80}$/.test(error?.code || "") ? error.code : "event_inbox_unavailable";
      const status = Number(error?.statusCode || error?.status);
      return res.status([400, 401, 403, 409, 413, 503].includes(status) ? status : 503)
        .json({ ok: false, code, retryable: ![400, 401, 403, 409, 413].includes(status) });
    }
  }
  return { handleRequest, processEvent: inbox.processEvent, sweep: inbox.sweep };
}

module.exports = { createOpsSlackEvents, describeOpsSlackEvents };
