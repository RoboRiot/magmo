const CACHE_NAME = "magmo-static-v2";
const ASSET_URLS = [
  "/manifest.json",
  "/icon-192.png",
  "/icon-512.png",
  "/apple-touch-icon.png",
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(ASSET_URLS))
      .catch(() => undefined)
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME)
            .map((key) => caches.delete(key))
        )
      )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (!ASSET_URLS.includes(url.pathname)) return;

  event.respondWith(
    caches.match(request).then((cached) => cached || fetch(request))
  );
});

// FCM uses the browser Push API. Keep one worker for both installation and
// notifications; data messages avoid a second automatic notification display.
self.addEventListener("push", (event) => {
  let payload;
  try { payload = event.data?.json(); } catch { return; }
  const data = payload?.data;
  if (!["magmonitor-health","ops-engineer"].includes(data?.kind) || !data.eventId) return;
  const ops = data.kind === "ops-engineer";
  const title = String(data.title || (ops ? "Magmo OT coverage" : "Magmo magnet monitoring")).slice(0,160);
  event.waitUntil(self.registration.showNotification(title, {
    body:String(data.body || "Open Magmo for details.").slice(0,400),
    icon:"/icon-192.png", badge:"/icon-192.png", tag:`${ops ? "ops-engineer" : "magmonitor"}-${data.eventId}`,
    renotify:false, data:{url:ops ? "/Ops-General?ot=1" : data.url || "/Magmonitor"},
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  let url = new URL("/Magmonitor",self.location.origin);
  try {
    const requested = new URL(event.notification.data?.url || "/Magmonitor",self.location.origin);
    if (requested.origin === self.location.origin && ["/Magmonitor","/Ops-General"].includes(requested.pathname)) url=requested;
  } catch { /* Use the known Magmonitor route. */ }
  event.waitUntil(self.clients.matchAll({type:"window",includeUncontrolled:true}).then(async windows => {
    const existing = windows.find(client => new URL(client.url).origin === url.origin);
    if (existing) { await existing.navigate(url.href); return existing.focus(); }
    return self.clients.openWindow(url.href);
  }));
});
