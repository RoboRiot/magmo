"use strict";

// Preserves the existing, explicitly requested DM help feature only. The
// evidence inbox never posts to Slack, and every !command stays Python-owned.
const { createHash } = require("node:crypto");
const EVENT_COLLECTION = "BlueFolderSlackEvents";
class SlackHelpError extends Error {
  constructor(code, statusCode = 503) { super(code); this.code = code; this.statusCode = statusCode; }
}
function buildSlackHelpText() {
  return [
    "*MAGMO commands*",
    "Use the work-order commands inside the corresponding Slack work-order thread.",
    "",
    "• `-help` — Show this command list in a direct message.",
    "• `!daily` — Post a short update for the current Pacific-time day.",
    "• `!complete` — Post the service report and move the work order to Service complete while parts return remains pending.",
    "• `!parts` — Post and save a concise parts-movement summary without changing the work-order status.",
    "• `!notes <note>` — Save a client/system note to the linked work order.",
    "• `!done` — Post the final closeout and mark the work order Done, preserving its summaries and message tracking.",
    "",
    "The Python command service handles work-order commands. Done and Service complete remain monitored; temporary message logs are cleared only when moved to Closed.",
    "Service completion uses `!complete`; `!service` is not currently an active command.",
  ].join("\n");
}
function createOpsSlackHelp({ db, env = process.env, fetch: request = globalThis.fetch, now = Date.now } = {}) {
  async function reply(event) {
    if (!event || event.kind !== "help" || event.text !== "-help" || event.edited !== false || event.processEvidence !== false
        || typeof event.eventId !== "string" || !/^Ev[A-Za-z0-9]{1,126}$/.test(event.eventId)
        || typeof event.senderId !== "string" || !/^[UW][A-Z0-9]{2,63}$/.test(event.senderId) || event.senderId === "USLACKBOT"
        || typeof event.channel !== "string" || !/^D[A-Z0-9]{2,63}$/.test(event.channel)
        || typeof event.messageTs !== "string" || !/^\d{10,12}\.\d{6}$/.test(event.messageTs)
        || !env.OPS_SLACK_EVENTS_TEAM_ID || !env.OPS_SLACK_EVENTS_APP_ID
        || event.teamId !== env.OPS_SLACK_EVENTS_TEAM_ID || event.appId !== env.OPS_SLACK_EVENTS_APP_ID) {
      throw new SlackHelpError("invalid_dm_help_event", 400);
    }
    const token = typeof env.SLACK_BOT_TOKEN === "string" ? env.SLACK_BOT_TOKEN.replace(/\s+#.*$/, "").trim() : "";
    if (!token || typeof request !== "function") throw new SlackHelpError("dm_help_unavailable");
    if (!db || typeof db.runTransaction !== "function") throw new SlackHelpError("dm_help_store_unavailable");
    const ref = db.collection(EVENT_COLLECTION).doc(event.eventId);
    const identityHash = createHash("sha256").update(JSON.stringify([event.teamId, event.appId, event.channel, event.messageTs, event.senderId, "-help"])).digest("hex");
    const claimed = await db.runTransaction(async transaction => {
      const snapshot = await transaction.get(ref);
      if (snapshot.exists) {
        const existing = snapshot.data() || {};
        if (existing.helpIdentityHash && existing.helpIdentityHash !== identityHash) throw new SlackHelpError("dm_help_event_id_collision", 409);
        return false;
      }
      transaction.set(ref, { event_id: event.eventId, received_at: new Date(now()).toISOString(), receivedAt: new Date(now()),
        kind: "dm_help", helpIdentityHash: identityHash, helpStatus: "claimed", senderId: event.senderId, channel: event.channel });
      return true;
    });
    if (!claimed) return { duplicate: true, posted: false, command: "-help" };
    try {
      const response = await request("https://slack.com/api/chat.postMessage", {
        method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json; charset=utf-8" },
        body: JSON.stringify({ channel: event.senderId, text: buildSlackHelpText(), mrkdwn: true, unfurl_links: false, unfurl_media: false,
          metadata: { event_type: "magmo_command_help", event_payload: { request_ts: event.messageTs } } }),
        signal: AbortSignal.timeout(2500),
      });
      const body = await response.json();
      if (!response.ok || body?.ok !== true) throw new SlackHelpError("dm_help_delivery_unconfirmed");
      await db.runTransaction(async transaction => {
        const snapshot = await transaction.get(ref);
        if (snapshot.data()?.helpIdentityHash === identityHash) transaction.set(ref, {
          helpStatus: "posted", helpCompletedAt: new Date(now()).toISOString(),
        }, { merge: true });
      });
      return { posted: true, duplicate: false, command: "-help" };
    } catch {
      // Preserve the existing at-most-once claim across ambiguous Slack errors:
      // a timeout must not cause repeated DMs on Slack's delivery retries.
      try {
        await db.runTransaction(async transaction => {
          const snapshot = await transaction.get(ref);
          if (snapshot.data()?.helpIdentityHash === identityHash) transaction.set(ref, {
            helpStatus: "delivery_unconfirmed", helpErrorCode: "dm_help_delivery_unconfirmed",
          }, { merge: true });
        });
      } catch { /* Do not expose infrastructure errors or credentials. */ }
      throw new SlackHelpError("dm_help_delivery_unconfirmed");
    }
  }
  return { reply };
}
module.exports = { createOpsSlackHelp, buildSlackHelpText, EVENT_COLLECTION };
