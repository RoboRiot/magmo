"use strict";

const { createHash } = require("node:crypto");

const EVENT_TYPE = "work_order.bluefolder_status";
const WORK_ORDER_COLLECTION = "OpsWorkOrders";
const OPEN_CLOCK_COLLECTION = "OpsOpenClocks";
const FUTURE_TOLERANCE_MS = 5 * 60 * 1000;
const STATUS_WRITE_FIELDS = Object.freeze([
  "status", "workflowStatus", "closedAt", "closedBy", "trackingStoppedAt",
  "workflowStageStartedAt", "workflowStageStartedAtIso", "workflowStageHistory",
  "bluefolderStatusSync", "updatedAt",
]);
const BLUEFOLDER_STATUS_SYNC_SCHEMA = Object.freeze({
  eventType: EVENT_TYPE,
  required: ["eventType", "workOrderId", "blueFolder", "observedAt"],
  blueFolderRequired: ["serviceRequestId", "status"],
  allowedStatuses: ["Closed"],
  optional: ["sourceUpdatedAt", "blueFolder.dateTimeClosed"],
  timestampFormat: "RFC3339 with an explicit timezone",
  statusOnly: true,
  createsWorkOrders: false,
  writesSlack: false,
  writesBlueFolder: false,
});

class BlueFolderStatusSyncError extends Error {
  constructor(code, message, statusCode = 400) {
    super(message);
    this.name = "BlueFolderStatusSyncError";
    this.code = code;
    this.statusCode = statusCode;
    this.retryable = statusCode >= 500;
  }
}

function fail(code, message, statusCode = 400) {
  throw new BlueFolderStatusSyncError(code, message, statusCode);
}

function object(value) {
  return value && typeof value === "object" && !Array.isArray(value);
}

function exactText(value, field, max = 180) {
  if (typeof value !== "string" || !value.trim() || value.length > max) {
    fail("invalid_bluefolder_status_payload", `${field} must be a nonempty string of at most ${max} characters.`);
  }
  return value.trim();
}

function timestampMs(value) {
  if (value == null || value === "") return 0;
  if (typeof value.toMillis === "function") return value.toMillis();
  if (typeof value.toDate === "function") return value.toDate().getTime();
  if (value instanceof Date) return value.getTime();
  if (typeof value === "object" && Number.isFinite(value._seconds ?? value.seconds)) {
    return Number(value._seconds ?? value.seconds) * 1000;
  }
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function validTimestamp(value, field, nowMs) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) {
    fail("invalid_bluefolder_status_timestamp", `${field} must be an RFC3339 timestamp with an explicit timezone.`);
  }
  const ms = Date.parse(value);
  if (!Number.isFinite(ms) || ms <= 0 || ms > nowMs + FUTURE_TOLERANCE_MS) {
    fail("invalid_bluefolder_status_timestamp", `${field} is invalid or in the future.`);
  }
  // Date.parse normalizes invalid month/day combinations. Reject those too.
  const [year, month, day] = value.slice(0, 10).split("-").map(Number);
  const [hour, minute, second] = value.slice(11, 19).split(":").map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) {
    fail("invalid_bluefolder_status_timestamp", `${field} contains an invalid calendar date.`);
  }
  return new Date(ms).toISOString();
}

function validateBlueFolderStatusSync(payload, { now = Date.now() } = {}) {
  const nowMs = typeof now === "function" ? now() : now;
  if (!object(payload) || !object(payload.blueFolder)) {
    fail("invalid_bluefolder_status_payload", "A BlueFolder status payload and blueFolder object are required.");
  }
  const allowed = new Set(["eventType", "workOrderId", "blueFolder", "observedAt", "sourceUpdatedAt"]);
  const allowedSource = new Set(["serviceRequestId", "status", "dateTimeClosed"]);
  const unknown = Object.keys(payload).filter(key => !allowed.has(key));
  unknown.push(...Object.keys(payload.blueFolder).filter(key => !allowedSource.has(key)).map(key => `blueFolder.${key}`));
  if (unknown.length) fail("bluefolder_status_unsupported_fields", `Unsupported fields: ${unknown.join(", ")}.`);
  if (payload.eventType !== EVENT_TYPE) fail("invalid_bluefolder_status_payload", `eventType must be ${EVENT_TYPE}.`);
  const workOrderId = exactText(payload.workOrderId, "workOrderId");
  const serviceRequestId = exactText(payload.blueFolder.serviceRequestId, "blueFolder.serviceRequestId");
  if (!/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,179}$/.test(workOrderId) || !/^\d+$/.test(serviceRequestId)) {
    fail("invalid_bluefolder_status_identity", "workOrderId must be a document ID and BlueFolder serviceRequestId must be its exact numeric service-request identity.");
  }
  if (exactText(payload.blueFolder.status, "blueFolder.status", 80).toLowerCase() !== "closed") {
    fail("bluefolder_status_not_closed", "Only an explicit BlueFolder Closed status is accepted.");
  }
  const observedAt = validTimestamp(payload.observedAt, "observedAt", nowMs);
  const dateTimeClosed = payload.blueFolder.dateTimeClosed === undefined
    ? "" : validTimestamp(payload.blueFolder.dateTimeClosed, "blueFolder.dateTimeClosed", nowMs);
  const sourceUpdatedAt = payload.sourceUpdatedAt === undefined
    ? "" : validTimestamp(payload.sourceUpdatedAt, "sourceUpdatedAt", nowMs);
  for (const [field, value] of [["blueFolder.dateTimeClosed", dateTimeClosed], ["sourceUpdatedAt", sourceUpdatedAt]]) {
    if (value && Date.parse(value) > Date.parse(observedAt) + FUTURE_TOLERANCE_MS) {
      fail("invalid_bluefolder_status_timestamp", `${field} cannot be later than the observed source state.`);
    }
  }
  return { eventType: EVENT_TYPE, workOrderId, blueFolder: { serviceRequestId, status: "Closed", ...(dateTimeClosed ? { dateTimeClosed } : {}) }, observedAt, ...(sourceUpdatedAt ? { sourceUpdatedAt } : {}) };
}

function verifiedBlueFolderIdentity(existing, serviceRequestId) {
  const identities = [];
  if (existing.bluefolderServiceRequestId !== undefined && existing.bluefolderServiceRequestId !== null && existing.bluefolderServiceRequestId !== "") {
    const value = String(existing.bluefolderServiceRequestId).trim();
    if (!/^\d+$/.test(value)) fail("bluefolder_identity_conflict", "The saved BlueFolder identity is invalid.", 409);
    identities.push(value);
  }
  if (existing.bluefolderUrl) {
    let url;
    try { url = new URL(existing.bluefolderUrl); } catch { fail("bluefolder_identity_conflict", "The saved BlueFolder link is invalid.", 409); }
    if (url.protocol !== "https:" || url.hostname !== "advancedimaging.bluefolder.com" || url.port || url.username || url.password || url.pathname !== "/service/sr.aspx" || url.searchParams.getAll("srid").length !== 1 || !/^\d+$/.test(url.searchParams.get("srid") || "")) {
      fail("bluefolder_identity_conflict", "The saved BlueFolder link is not an authoritative service-request link.", 409);
    }
    identities.push(url.searchParams.get("srid"));
  }
  if (!identities.length) fail("bluefolder_identity_unverified", "The Magmo work order has no verified BlueFolder service-request identity.", 409);
  if (identities.some(value => value !== serviceRequestId)) fail("bluefolder_identity_conflict", "The BlueFolder service-request identity does not match this Magmo work order.", 409);
}

function currentStage(existing) {
  if (String(existing.status || "").toLowerCase() === "closed") return "closed";
  const stage = String(existing.workflowStatus || existing.workflowStage || "").toLowerCase();
  if (stage) return stage;
  return ["completed", "complete", "done"].includes(existing.status) ? "done" : "active";
}

function latestManualMove(existing) {
  const values = [existing.reopenedAt, existing.reopenedAtIso, existing.workflowManualOverrideAt];
  for (const entry of Array.isArray(existing.workflowStageHistory) ? existing.workflowStageHistory : []) {
    if (["reopen", "manual_stage_move", "admin_correction"].includes(entry?.source)) {
      values.push(entry.exitedAt, entry.exitedAtIso);
    }
  }
  if (existing.aiWorkflowReview?.status === "reviewed") {
    values.push(existing.aiWorkflowReview.reviewedAt, existing.aiWorkflowReview.reviewedAtIso);
  }
  return Math.max(0, ...values.map(timestampMs));
}

function closureFingerprint(payload) {
  return createHash("sha256").update(JSON.stringify([
    payload.blueFolder.serviceRequestId,
    "Closed",
    payload.blueFolder.dateTimeClosed || "undated",
  ])).digest("hex");
}

function planBlueFolderStatusSync(existing, input, { now = Date.now(), activeClockCount = 0 } = {}) {
  const nowMs = typeof now === "function" ? now() : now;
  const payload = validateBlueFolderStatusSync(input, { now: nowMs });
  if (!existing || existing.deletedAt || existing.deleted === true) fail("work_order_not_found", "This Magmo work order does not exist or has been deleted.", 404);
  verifiedBlueFolderIdentity(existing, payload.blueFolder.serviceRequestId);
  const previous = object(existing.bluefolderStatusSync) ? existing.bluefolderStatusSync : {};
  const fingerprint = closureFingerprint(payload);
  const noChange = reason => ({ payload, patch: {}, reason, idempotentReplay: ["already_closed", "repeated_closure"].includes(reason), statusChanged: false });
  const observedMs = Date.parse(payload.observedAt);
  const closeMs = timestampMs(payload.blueFolder.dateTimeClosed);
  const sourceMs = timestampMs(payload.sourceUpdatedAt);
  if (observedMs < timestampMs(previous.observedAt) ||
      (sourceMs && sourceMs < timestampMs(previous.sourceUpdatedAt)) ||
      (closeMs && closeMs < timestampMs(previous.sourceClosedAt))) return noChange("out_of_order");
  if (currentStage(existing) === "closed") return noChange("already_closed");
  const manualMs = latestManualMove(existing);
  const undatedManualLock = Boolean(existing.reopenedBy || existing.workflowManualOverrideAt || existing.aiWorkflowReview?.status === "reviewed") && !manualMs;
  if (undatedManualLock || (manualMs && (!closeMs || closeMs <= manualMs))) return noChange("manual_reopen_protected");
  if (previous.closureFingerprint === fingerprint) return noChange("repeated_closure");
  // A source version does not prove a new close event after a local reopen.
  // dateTimeClosed must establish that transition; unrelated BF edits cannot.
  const nowIso = new Date(nowMs).toISOString();
  const stage = currentStage(existing);
  const enteredMs = timestampMs(existing.workflowStageStartedAt) || timestampMs(existing.workflowStageStartedAtIso) || timestampMs(existing.createdAt) || timestampMs(existing.createdAtIso) || nowMs;
  const history = Array.isArray(existing.workflowStageHistory) ? existing.workflowStageHistory.slice() : [];
  history.push({
    id: `bluefolder-close-${fingerprint.slice(0, 20)}`,
    stage,
    enteredAtIso: new Date(enteredMs).toISOString(),
    exitedAtIso: nowIso,
    durationMs: Math.max(0, nowMs - enteredMs),
    source: "bluefolder_status_sync",
    changedBy: "BlueFolder status sync",
    reason: "Automatically closed from BlueFolder. Status only; saved evidence, hours and other work-order data were preserved.",
  });
  const patch = {
    status: "closed",
    workflowStatus: "closed",
    closedAt: new Date(nowMs),
    closedBy: "BlueFolder status sync",
    trackingStoppedAt: new Date(nowMs),
    workflowStageStartedAt: new Date(nowMs),
    workflowStageStartedAtIso: nowIso,
    workflowStageHistory: history,
    bluefolderStatusSync: {
      version: "2026-09-24.1",
      sourceStatus: "Closed",
      serviceRequestId: payload.blueFolder.serviceRequestId,
      sourceClosedAt: payload.blueFolder.dateTimeClosed || "",
      sourceUpdatedAt: payload.sourceUpdatedAt || "",
      observedAt: payload.observedAt,
      appliedAt: nowIso,
      closureFingerprint: fingerprint,
      statusOnly: true,
      activeClockCount,
      reviewRequired: activeClockCount > 0,
      reviewReason: activeClockCount > 0 ? "A clock remains open. BlueFolder closure was not used as an engineer departure or clock-out time." : "",
    },
    updatedAt: new Date(nowMs),
  };
  if (Object.keys(patch).some(field => !STATUS_WRITE_FIELDS.includes(field))) throw new Error("BlueFolder status sync attempted a non-status write.");
  return { payload, patch, reason: "applied", idempotentReplay: false, statusChanged: true };
}

function authoritativeValue(value, ancestors = new WeakSet()) {
  if (value instanceof Date) return value.toISOString();
  if (value && typeof value.toDate === "function") return value.toDate().toISOString();
  if (!value || typeof value !== "object") return value;
  // Firestore references contain the entire internal client (including cyclic
  // state and credentials). Return only the domain reference, never enumerate
  // SDK internals. This must precede generic object serialization.
  if (typeof value.path === "string" && (
    value.constructor?.name === "DocumentReference" || "firestore" in value || "_firestore" in value ||
    (typeof value.get === "function" && typeof value.set === "function")
  )) return { path: value.path };
  if (value.constructor?.name === "GeoPoint" && Number.isFinite(value.latitude) && Number.isFinite(value.longitude)) {
    return { latitude: value.latitude, longitude: value.longitude };
  }
  if (Buffer.isBuffer(value) || value instanceof Uint8Array) return { bytesBase64: Buffer.from(value).toString("base64") };
  if (ancestors.has(value)) return "[Circular reference]";
  ancestors.add(value);
  let result;
  if (Array.isArray(value)) result = value.map(entry => authoritativeValue(entry, ancestors));
  else if (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) {
    result = Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, authoritativeValue(entry, ancestors)]));
  } else {
    // Unknown SDK/class objects are not domain records; exposing their own
    // properties could leak transport/client state.
    result = null;
  }
  ancestors.delete(value);
  return result;
}

async function syncBlueFolderClosedStatus({ db, payload: input, now = Date.now }) {
  if (!db || typeof db.collection !== "function" || typeof db.runTransaction !== "function") {
    fail("bluefolder_status_storage_unavailable", "Magmo status storage is temporarily unavailable.", 503);
  }
  const nowMs = typeof now === "function" ? now() : now;
  const payload = validateBlueFolderStatusSync(input, { now: nowMs });
  const ref = db.collection(WORK_ORDER_COLLECTION).doc(payload.workOrderId);
  return db.runTransaction(async transaction => {
    const snapshot = await transaction.get(ref);
    if (!snapshot.exists) fail("work_order_not_found", "This Magmo work order does not exist.", 404);
    const before = snapshot.data();
    const preliminary = planBlueFolderStatusSync(before, payload, { now: nowMs });
    let plan = preliminary;
    if (preliminary.statusChanged) {
      const openClocks = await transaction.get(db.collection(OPEN_CLOCK_COLLECTION).where("workOrderId", "==", payload.workOrderId));
      plan = planBlueFolderStatusSync(before, payload, { now: nowMs, activeClockCount: openClocks.docs.length });
      // update (not set/create) plus a closed field allowlist keeps this operation
      // restricted to existing Magmo status metadata, even on retries.
      transaction.update(ref, plan.patch);
    }
    return {
      ok: true,
      eventType: EVENT_TYPE,
      workOrderId: payload.workOrderId,
      number: String(before.number || before.workOrderId || payload.workOrderId),
      blueFolder: { serviceRequestId: payload.blueFolder.serviceRequestId },
      created: false,
      statusChanged: plan.statusChanged,
      idempotentReplay: plan.idempotentReplay,
      reason: plan.reason,
      before: authoritativeValue(before),
      after: authoritativeValue({ ...before, ...plan.patch }),
      appliedChanges: authoritativeValue(plan.patch),
    };
  });
}

module.exports = {
  EVENT_TYPE, WORK_ORDER_COLLECTION, OPEN_CLOCK_COLLECTION,
  STATUS_WRITE_FIELDS, BLUEFOLDER_STATUS_SYNC_SCHEMA, BlueFolderStatusSyncError,
  validateBlueFolderStatusSync, verifiedBlueFolderIdentity, planBlueFolderStatusSync,
  syncBlueFolderClosedStatus,
};
