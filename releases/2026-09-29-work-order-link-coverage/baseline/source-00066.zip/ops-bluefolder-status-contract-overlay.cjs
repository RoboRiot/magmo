"use strict";

// Applied to the exact deployed contract, never a replacement from the working tree.
const sync = require("./.next/server/chunks/blueFolderStatusSync.cjs");
const additions = require("./ops-bluefolder-status-schema.json");
const EVENT_TYPE = "work_order.bluefolder_status";

function extendContract(base) {
  const includeEvent = (values) => Object.freeze([...new Set([...values, EVENT_TYPE])]);
  const classifyOpsError = (error) => error instanceof sync.BlueFolderStatusSyncError
    ? new base.OpsHttpError(error.statusCode, error.code, error.message, { retryable: error.retryable })
    : base.classifyOpsError(error);
  return {
    ...base,
    API_VERSION: additions.apiVersion,
    WRITE_EVENT_TYPES: includeEvent(base.WRITE_EVENT_TYPES),
    SUPPORTED_EVENT_TYPES: includeEvent(base.SUPPORTED_EVENT_TYPES),
    validateIngestRequest(body) {
      if (body && !Array.isArray(body) && body.eventType === EVENT_TYPE) {
        const normalized = sync.validateBlueFolderStatusSync(body);
        return { eventType: EVENT_TYPE, body, workOrderId: normalized.workOrderId };
      }
      return base.validateIngestRequest(body);
    },
    classifyOpsError,
    errorResponse(error, requestId) {
      const response = base.errorResponse(classifyOpsError(error), requestId);
      return { ...response, body: { ...response.body, apiVersion: additions.apiVersion } };
    },
    runtimeCapabilities(env) {
      const previous = base.runtimeCapabilities(env);
      return {
        ...previous,
        apiVersion: additions.apiVersion,
        supportedEventTypes: includeEvent(previous.supportedEventTypes),
        bluefolderStatusSync: additions.capability,
      };
    },
    buildOpenApiSpec() {
      const spec = base.buildOpenApiSpec();
      spec.info.version = additions.apiVersion;
      spec["x-magmo-capabilities"].bluefolderStatusSync = additions.capability;
      Object.assign(spec.components.schemas, additions.schemas);
      spec.components.schemas.IngestRequest.oneOf.unshift({ $ref: "#/components/schemas/BlueFolderStatusSyncRequest" });
      const ingest = spec.paths["/api/ops/ingest"].post;
      ingest.requestBody.content["application/json"].examples.blueFolderStatus = additions.example;
      ingest.responses[200].content["application/json"].schema.oneOf.unshift({ $ref: "#/components/schemas/BlueFolderStatusSyncResponse" });
      return spec;
    },
  };
}

module.exports = { extendContract };
