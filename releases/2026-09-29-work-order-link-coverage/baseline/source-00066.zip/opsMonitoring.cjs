"use strict";
const { createOpsSlackNeedsLink } = require("./opsSlackNeedsLink.cjs");
const QUEUE = "opsSlackEventInbox";
const CHANNEL = "C07EPLKV9JT";
const clean = (value, max = 300) => typeof value === "string" ? value.trim().slice(0, max) : "";
const numeric = value => Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : 0;
function isAdmin(user) {
  if (!user?.uid || user.magmoAccessRevoked === true) return false;
  const role = clean(user.role).toLowerCase().replace(/[\s-]+/g, "_");
  return user.isAdmin === true || ["admin", "master_admin"].includes(role) || (user.email_verified === true && clean(user.email).toLowerCase() === "isavchenko@advancedimagingparts.com");
}
function summarize(rows, now) {
  const pending = rows.filter(row => ["pending", "retry", "processing"].includes(row.state));
  const oldest = pending.reduce((age, row) => Math.max(age, now - Number(row.receivedAtMs || now)), 0);
  const recentFailures = rows.filter(row => Number(row.updatedAtMs) > now - 15 * 60000 && ["retry", "dead_letter"].includes(row.state) && Number(row.attempts) >= 3 && row.lastCode !== "work_order_not_found");
  const needsLink = rows.filter(row => row.state === "needs_link" || (row.state === "dead_letter" && row.lastCode === "work_order_not_found"));
  const warnings = [];
  if (oldest > 5 * 60000) warnings.push({ code: "queue_age", message: `The oldest pending Slack message has waited ${Math.floor(oldest / 60000)} minutes.` });
  if (recentFailures.length) warnings.push({ code: "repeated_worker_failures", message: `${recentFailures.length} messages have repeated worker failures in the last 15 minutes.` });
  if (needsLink.length) warnings.push({ code: "needs_work_order_link", message: `${needsLink.length} Slack messages need a work-order link.` });
  return { pendingCount: pending.length, oldestPendingAgeSeconds: Math.floor(oldest / 1000), repeatedFailureCount: recentFailures.length, needsLinkCount: needsLink.length, warnings };
}
function publicHealth(snapshot, source) {
  const row = snapshot.exists ? snapshot.data() : {};
  const counts = Object.fromEntries(["completed", "retry", "ignored", "needs_link", "dead_letter", "failure"].map(state => [state, numeric(row.counts?.[state])]));
  return { source, sinceMs: numeric(row.sinceMs) || null, updatedAtMs: numeric(row.updatedAtMs) || null,
    lastCompletedAtMs: numeric(row.lastCompletedAtMs) || null, lastFailureAtMs: numeric(row.lastFailureAtMs) || null,
    lastState: ["completed", "retry", "ignored", "needs_link", "dead_letter"].includes(row.lastState) ? row.lastState : "", lastCode: /^[a-z0-9_]{1,100}$/.test(row.lastCode || "") ? row.lastCode : "", counts };
}
function publicRow(row) {
  const event = row.event || {};
  return { id: row.id, state: row.state, receivedAtMs: row.receivedAtMs, attempts: row.attempts || 0, code: clean(row.lastCode),
    threadTs: clean(event.threadTs, 80), messageTs: clean(event.messageTs, 80), senderId: clean(event.senderId, 80),
    text: event.payloadRedacted ? "Original message payload is no longer retained. Open Slack to review." : clean(event.text, 2000) || "Attachment-only message",
    canLink: row.state === "needs_link" && event.channel === CHANNEL && !event.payloadRedacted,
    slackUrl: event.channel === CHANNEL && /^\d{10}\.\d{6}$/.test(event.messageTs || event.threadTs || "") ? `https://app.slack.com/archives/${CHANNEL}/p${String(event.messageTs || event.threadTs).replace(".", "")}` : null };
}
function createOpsMonitoring({ db, auth, now = Date.now }) {
  let cache = null;
  async function snapshot() {
    if (cache && now() - cache.at < 15000) return cache.value;
    const [active, recent, reviews, astra, ...healthDocs] = await Promise.all([
      db.collection(QUEUE).where("state", "in", ["pending", "retry", "processing", "needs_link"]).limit(500).get(),
      db.collection(QUEUE).where("updatedAtMs", ">", now() - 15 * 60000).limit(500).get(),
      db.collection(QUEUE).where("state", "==", "dead_letter").limit(100).get(),
      db.collection("OpsAstraReviewQueue").where("status", "in", ["pending", "retry", "processing"]).limit(100).get(),
      ...["trigger", "sweep"].map(source => db.collection("opsSlackEventLocks").doc(`_health_${source}`).get()),
    ]);
    const all = new Map([...active.docs, ...recent.docs, ...reviews.docs].map(doc => [doc.id, { ...doc.data(), id: doc.id }]));
    const rows = [...all.values()], summary = summarize(rows, now());
    const workerHealth = Object.fromEntries(["trigger", "sweep"].map((source, index) => [source, publicHealth(healthDocs[index], source)]));
    const trigger = workerHealth.trigger;
    if (["retry", "dead_letter"].includes(trigger.lastState) && trigger.lastCode !== "work_order_not_found" && trigger.lastFailureAtMs > now() - 15 * 60000) {
      summary.warnings.push({ code: "immediate_worker_failure", message: "The immediate Slack worker recently reported a processing failure. The recovery sweep remains available." });
    }
    const items = rows.filter(row => row.state === "needs_link" || (row.state === "dead_letter" && row.lastCode === "work_order_not_found")).sort((a, b) => a.receivedAtMs - b.receivedAtMs).map(publicRow);
    const value = { ok: true, checkedAt: new Date(now()).toISOString(), ...summary, astraPendingCount: astra.docs.length, items,
      bounded: active.docs.length === 500 || recent.docs.length === 500 || reviews.docs.length === 100 || astra.docs.length === 100,
      workerHealth,
      lastTriggerSuccessAtMs: rows.filter(row => row.state === "completed" && (row.completedBy === "trigger" || row.processingSource === "trigger")).reduce((latest, row) => Math.max(latest, numeric(row.completedAtMs || row.updatedAtMs)), trigger.lastCompletedAtMs || 0) || null };
    cache = { at: now(), value }; return value;
  }
  async function handleRequest(req, res) {
    res.setHeader("Cache-Control", "private, no-store");
    try {
      const token = /^Bearer\s+(.+)$/i.exec(req.headers?.authorization || "")?.[1];
      if (!token) return res.status(401).json({ ok: false, error: "Sign in to view Ops monitoring." });
      let user;
      try { user = await auth.verifyIdToken(token, true); } catch (_) { return res.status(401).json({ ok: false, error: "Your session has expired. Sign in again." }); }
      if (!isAdmin(user)) return res.status(403).json({ ok: false, error: "Ops administrator access is required." });
      if (req.method === "GET") {
        if (req.query?.options === "1" || /[?&]options=1(?:&|$)/.test(req.url || "")) {
          const docs = await db.collection("OpsWorkOrders").limit(1001).get();
          return res.status(200).json({ ok: true, bounded: docs.docs.length > 1000, workOrders: docs.docs.slice(0, 1000).filter(doc => { const d = doc.data(); return !d.deletedAt && d.deleted !== true && d.isDeleted !== true && !["closed", "deleted"].includes(clean(d.workflowStatus || d.workflowStage || d.status).toLowerCase()); }).map(doc => ({ id: doc.id, number: clean(String(doc.data().number || doc.id), 100), subject: clean(doc.data().subject || doc.data().title, 220) })) });
        }
        return res.status(200).json(await snapshot());
      }
      if (req.method !== "POST") { res.setHeader("Allow", "GET, POST"); return res.status(405).json({ ok: false, error: "Method not allowed." }); }
      const body = req.body;
      if (!body || typeof body !== "object" || Array.isArray(body) || !["link", "ignore"].includes(body.action)) return res.status(400).json({ ok: false, error: "Choose a valid review action." });
      if (typeof body.reason !== "string" || !body.reason.trim() || body.reason.trim().length > 1000) return res.status(400).json({ ok: false, error: "A review reason of 1–1000 characters is required." });
      if (typeof body.eventId !== "string" || !/^[A-Za-z0-9_-]{1,180}$/.test(body.eventId)
          || (body.action === "link" && (typeof body.workOrderId !== "string" || !/^[A-Za-z0-9_-]{1,180}$/.test(body.workOrderId)))) return res.status(400).json({ ok: false, error: "Choose a valid message and work order." });
      const result = await createOpsSlackNeedsLink({ db, now }).resolve({ eventId: body.eventId, action: body.action, workOrderId: body.workOrderId, actorId: user.uid, reason: body.reason.trim() });
      cache = null;
      return res.status(200).json({ ok: true, ...result });
    } catch (error) {
      const status = [400, 404, 409].includes(error.statusCode) ? error.statusCode : 503;
      return res.status(status).json({ ok: false, code: /^[a-z_]{1,100}$/.test(error.code || "") ? error.code : "monitoring_unavailable", error: status === 503 ? "Ops monitoring is temporarily unavailable. Retry shortly." : "The review could not be applied. Refresh and check the selected work order and message." });
    }
  }
  return { handleRequest, snapshot };
}
module.exports = { createOpsMonitoring, isAdmin, summarize, publicRow, publicHealth };
