"use strict";

// Optional shadow work only. No imports capable of mutating live decisions,
// official clocks, Slack or BlueFolder. The production ingest path only queues.
const { createHash, randomUUID } = require("node:crypto");
const trial = require("./opsAstraTrial.cjs");
const contract = require("./opsAstraTrialContract.cjs");
const config = require("./opsAstraTrialConfig.json");
const QUEUE_COLLECTION = "OpsAstraReviewQueue";
const LEASE_MS = 240000;
const MAX_ATTEMPTS = 2;
const TERMINAL = new Set(["completed", "failed", "skipped"]);
const hash = value => createHash("sha256").update(value).digest("hex");
const clean = (value, max = 180) => typeof value === "string" ? value.trim().slice(0, max) : "";
const iso = now => new Date(now).toISOString();
const validId = value => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);

function compactWorkOrder(value = {}) {
  const people = rows => (Array.isArray(rows) ? rows : []).slice(0, 40).map(row => ({ id: clean(row?.id, 80), name: clean(row?.name, 100) }));
  return {
    id: clean(value.id || value.number), number: clean(String(value.number || ""), 100),
    subject: clean(value.subject, 400), workflowStatus: clean(value.workflowStatus, 40),
    workMode: clean(value.workMode, 40), slackChannel: clean(value.slackChannel, 40),
    slackThreadTs: clean(value.slackThreadTs, 40),
    assignees: people(value.assignees), participants: people(value.participants),
    bluefolderAssignees: people(value.bluefolderAssignees), reason: clean(value.reason, 700),
  };
}

function identity(workOrder, message) {
  const workOrderId = clean(workOrder?.id || workOrder?.number);
  const slackTs = clean(message?.slackTs, 40);
  const revision = clean(message?.revisionToken, 100) || hash(JSON.stringify([
    message?.slackVersionTs || slackTs, message?.sender?.id, clean(message?.text, 6000),
  ]));
  return { workOrderId, slackTs, revision, jobId: hash(`${config.id}:${workOrderId}:${slackTs}:${revision}`) };
}

async function enqueueOpsAstraMessage(args, dependencies = {}) {
  if (!trial.eligible(args) || args.baseline?.workflowStatus === "closed") return { skipped: true, reason: "ineligible" };
  const db = dependencies.db || require("firebase-admin/firestore").getFirestore();
  const now = args.now ?? Date.now();
  const id = identity(args.workOrder, args.message);
  const ref = db.collection(QUEUE_COLLECTION).doc(id.jobId);
  const legacy = db.collection("OpsAiTrials").doc(config.id).collection("runs").doc(hash(`${id.workOrderId}:${id.slackTs}`));
  // Cheap duplicate check before loading any context. Transaction rechecks it.
  const existing = await ref.get();
  if (existing.exists) return { queued: false, duplicate: true, jobId: id.jobId };
  const context = await trial.loadContext(db, id.workOrderId, args.message);
  const workOrder = compactWorkOrder(args.workOrder);
  const baseline = compactWorkOrder(args.baseline || args.workOrder);
  const request = contract.buildReviewRequest({ workOrder, baseline, ...context, nowIso: iso(now) });
  return db.runTransaction(async tx => {
    const [current, oldRun, order] = await Promise.all([
      tx.get(ref), tx.get(legacy), tx.get(db.collection("OpsWorkOrders").doc(id.workOrderId)),
    ]);
    if (current.exists || oldRun.exists) return { queued: false, duplicate: true, jobId: id.jobId };
    if (!order.exists || order.data()?.deletedAt || order.data()?.workflowStatus === "closed") return { skipped: true, reason: "closed_or_missing" };
    tx.set(ref, {
      ...id, trialId: config.id, status: "pending", pending: true, attempts: 0,
      createdAt: iso(now), createdAtMs: now, dueAtMs: now, leaseUntilMs: 0,
      messageId: clean(args.message.id), workOrder, baseline, context, request,
      changesLiveDecisions: false, changesOfficialHours: false,
    });
    return { queued: true, jobId: id.jobId };
  });
}

const SAFE_CODES = new Set([
  "rate_limit_exceeded", "slow_down", "server_error", "server_is_overloaded",
  "insufficient_quota", "billing_hard_limit_reached", "organization_spend_limit_exceeded",
  "project_spend_limit_exceeded", "organization_usage_limit_exceeded", "invalid_api_key",
  "model_not_found", "permission_denied", "context_length_exceeded", "ECONNRESET", "ETIMEDOUT", "ENOTFOUND",
]);
function safeRequestId(value) { return typeof value === "string" && /^[A-Za-z0-9_-]{1,160}$/.test(value) ? value : ""; }
function classifyError(error, clientRequestId, now = Date.now()) {
  const status = Number(error?.status);
  const code = SAFE_CODES.has(error?.code) ? error.code : "";
  const name = clean(error?.name, 80);
  let errorClass = "unknown";
  if (/quota|spend_limit|usage_limit|billing_hard_limit/.test(code)) errorClass = "quota";
  else if (status === 401 || code === "invalid_api_key") errorClass = "authentication";
  else if (status === 403 || code === "model_not_found" || code === "permission_denied") errorClass = "permission";
  else if (name === "AbortError" || name === "APITimeoutError" || code === "ETIMEDOUT") errorClass = "timeout";
  else if (name === "APIConnectionError" || ["ECONNRESET", "ENOTFOUND"].includes(code)) errorClass = "connection";
  else if (name === "AstraIncompleteError") errorClass = "incomplete";
  else if (name === "AstraSchemaError" || name === "SyntaxError") errorClass = "schema";
  else if (status === 429) errorClass = "rate_limit";
  else if (status >= 500 || status === 408) errorClass = "server";
  else if (status >= 400) errorClass = "request";
  const header = name => error?.headers?.get?.(name) ?? error?.headers?.[name];
  const rawRetry = header("retry-after");
  const seconds = Number(rawRetry);
  const retryAfterMs = rawRetry == null ? 0 : Number.isFinite(seconds) && seconds >= 0
    ? seconds * 1000 : Math.max(0, Date.parse(String(rawRetry)) - now) || 0;
  return {
    errorClass, errorCode: code || errorClass,
    httpStatus: Number.isInteger(status) && status >= 100 && status <= 599 ? status : null,
    requestId: safeRequestId(error?.request_id || error?._request_id || header("x-request-id")),
    clientRequestId: safeRequestId(clientRequestId),
    retryable: ["timeout", "connection", "rate_limit", "server"].includes(errorClass),
    retryAfterMs,
  };
}

async function runAttempt({ db, job, now, env = process.env }, dependencies = {}) {
  const reservation = await trial.reserve(db, {
    workOrderId: job.workOrderId, slackTs: job.slackTs, request: job.request, now,
    attemptKey: `queue:${job.jobId}:${job.attempts}`, jobId: job.jobId, attempt: job.attempts,
  });
  if (!reservation) return { status: "skipped", reason: "duplicate_disabled_or_budget", retryable: false };
  const clientRequestId = `ops-astra-${job.jobId.slice(0, 24)}-${job.attempts}`;
  const started = Date.now();
  const controller = new AbortController();
  const timeoutMs = dependencies.timeoutMs ?? config.timeoutMs;
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let usage = null;
  let result;
  try {
    const client = dependencies.client || new (require("openai").OpenAI)({ apiKey: env.OPENAI_API_KEY, timeout: timeoutMs, maxRetries: 0 });
    const response = await client.responses.create(job.request, {
      timeout: timeoutMs, maxRetries: 0, signal: controller.signal,
      headers: { "X-Client-Request-Id": clientRequestId },
    });
    try { usage = contract.normalizeUsage(response.usage); } catch { throw Object.assign(new Error("invalid_usage"), { name: "AstraSchemaError" }); }
    if (response.status && response.status !== "completed") throw Object.assign(new Error("incomplete"), { name: "AstraIncompleteError", request_id: response._request_id });
    const text = response.output_text || (response.output || []).flatMap(item => item.content || [])
      .filter(item => item.type === "output_text").map(item => item.text || "").join("");
    let review;
    try { review = contract.validateReview(JSON.parse(text), job.context.messages, job.workOrder); }
    catch { throw Object.assign(new Error("invalid_review"), { name: "AstraSchemaError", request_id: response._request_id }); }
    result = {
      status: "completed", usage, latencyMs: Date.now() - started,
      requestId: safeRequestId(response._request_id), clientRequestId,
      contextTruncated: job.context.contextTruncated, sourceMessageCount: job.context.messages.length,
      baseline: job.baseline, review, comparison: contract.compareReview(job.baseline, review), retryable: false,
    };
  } catch (error) {
    result = {
      status: "failed", ...(usage ? { usage } : {}), latencyMs: Date.now() - started,
      ...classifyError(controller.signal.aborted ? { name: "APITimeoutError" } : error, clientRequestId, now),
    };
  } finally { clearTimeout(timer); }
  const latestOrder = await db.collection("OpsWorkOrders").doc(job.workOrderId).get();
  if (!latestOrder.exists || latestOrder.data()?.deletedAt || latestOrder.data()?.workflowStatus === "closed") {
    // A close while inference was in flight invalidates the review; retain only
    // usage/accounting metadata, never apply or retain a stale proposed decision.
    result = { status: "skipped", reason: "closed_during_review", usage,
      latencyMs: Date.now() - started, clientRequestId, retryable: false };
  }
  // Await accounting before releasing the worker. Unlike the former ingestion
  // race, no unawaited continuation is left behind after the HTTP ack.
  await trial.finish(db, reservation, result);
  return { ...result, runId: reservation.runId };
}

async function processAstraJob({ db, jobId, now = Date.now(), env = process.env }, dependencies = {}) {
  if (!validId(jobId)) throw new Error("invalid_astra_job_id");
  const ref = db.collection(QUEUE_COLLECTION).doc(jobId);
  const leaseToken = randomUUID();
  const job = await db.runTransaction(async tx => {
    const snapshot = await tx.get(ref);
    if (!snapshot.exists) return null;
    const data = snapshot.data();
    if (TERMINAL.has(data.status) || data.dueAtMs > now || data.leaseUntilMs > now) return null;
    const order = await tx.get(db.collection("OpsWorkOrders").doc(data.workOrderId));
    let reason = "";
    if (!trial.trialCapabilities(now, env).enabled) reason = "trial_disabled_or_expired";
    else if ((env.GCLOUD_PROJECT || env.GOOGLE_CLOUD_PROJECT || env.FIREBASE_ADMIN_PROJECT_ID) !== config.projectId) reason = "wrong_project";
    else if (!order.exists || order.data()?.deletedAt || order.data()?.workflowStatus === "closed") reason = "closed_or_missing";
    else if (order.data()?.slackChannel !== "C07EPLKV9JT") reason = "non_dispatch";
    else if (now - Number(data.slackTs) * 1000 > 24 * 60 * 60 * 1000) reason = "stale_message";
    else if (data.attempts >= MAX_ATTEMPTS) reason = "attempt_limit";
    else if (data.status === "processing") reason = "interrupted_attempt_uncertain";
    if (reason) {
      tx.set(ref, { status: "skipped", reason, pending: false, dueAtMs: 0, completedAt: iso(now),
        context: null, request: null, baseline: null, workOrder: null, leaseUntilMs: 0 }, { merge: true });
      return null;
    }
    if (data.messageId) {
      const message = await tx.get(db.collection("OpsWorkOrders").doc(data.workOrderId).collection("messages").doc(data.messageId));
      if (!message.exists || (message.data()?.revisionToken && message.data().revisionToken !== data.revision)) {
        tx.set(ref, { status: "skipped", reason: "missing_or_superseded_revision", pending: false, dueAtMs: 0,
          completedAt: iso(now), context: null, request: null, baseline: null, workOrder: null }, { merge: true });
        return null;
      }
    }
    const attempts = Number(data.attempts || 0) + 1;
    tx.set(ref, { status: "processing", attempts, leaseToken, leaseUntilMs: now + LEASE_MS, dueAtMs: now + LEASE_MS, startedAt: iso(now) }, { merge: true });
    return { ...data, jobId, attempts, leaseToken };
  });
  if (!job) return { skipped: true };
  const result = await runAttempt({ db, job, now, env }, dependencies);
  const finishedNow = dependencies.now ? dependencies.now() : Date.now();
  const retryAt = finishedNow + Math.max(30000, result.retryAfterMs || 0);
  const retry = result.retryable === true && job.attempts < MAX_ATTEMPTS && retryAt < Date.parse(config.endsAt);
  await db.runTransaction(async tx => {
    const snapshot = await tx.get(ref);
    if (snapshot.data()?.leaseToken !== leaseToken) return;
    tx.set(ref, {
      status: retry ? "retry" : result.status, pending: retry, dueAtMs: retry ? retryAt : 0,
      leaseUntilMs: 0, leaseToken: "", completedAt: retry ? null : iso(finishedNow),
      lastResult: { status: result.status, reason: result.reason || "", runId: result.runId || "",
        errorClass: result.errorClass || "", errorCode: result.errorCode || "", httpStatus: result.httpStatus ?? null,
        requestId: result.requestId || "", clientRequestId: result.clientRequestId || "", latencyMs: result.latencyMs || 0 },
      ...(!retry ? { context: null, request: null, baseline: null, workOrder: null } : {}),
    }, { merge: true });
  });
  return { status: retry ? "retry" : result.status, jobId, attempt: job.attempts, runId: result.runId || "" };
}

async function sweepAstraJobs({ db, now = Date.now(), env = process.env, limit = 2 }, dependencies = {}) {
  // Single-field dueAtMs query avoids a new composite index; terminal jobs use 0.
  // Every pending/leased job carries a positive due time and no terminal does.
  const rows = await db.collection(QUEUE_COLLECTION).where("dueAtMs", ">", 0).where("dueAtMs", "<=", now).orderBy("dueAtMs").limit(Math.min(4, Math.max(1, limit))).get();
  const results = [];
  for (const row of rows.docs) results.push(await processAstraJob({ db, jobId: row.id, now, env }, dependencies));
  return { examined: rows.size, results };
}

module.exports = { QUEUE_COLLECTION, LEASE_MS, MAX_ATTEMPTS, identity, compactWorkOrder, classifyError,
  enqueueOpsAstraMessage, runAttempt, processAstraJob, sweepAstraJobs };
