"use strict";

const PROJECT_ID = "magmo-ac10c";
const DATABASE_ID = "(default)";
const COLLECTION = "opsSlackEventInbox";
const CREATED_TYPE = "google.cloud.firestore.document.v1.created";

function fail(code) { const error = new Error(code); error.code = code; throw error; }
function extractInboxEventId(event, { projectId = PROJECT_ID, databaseId = DATABASE_ID } = {}) {
  if (!event || event.type !== CREATED_TYPE) fail("unexpected_firestore_event_type");
  const expectedSource = `//firestore.googleapis.com/projects/${projectId}/databases/${databaseId}`;
  if (event.source !== expectedSource || (event.project && event.project !== projectId)
      || (event.database && event.database !== databaseId)) fail("unexpected_firestore_database");
  const snapshot = event.data;
  const id = snapshot?.id;
  if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,180}$/.test(id)) fail("invalid_inbox_document_id");
  const path = `${COLLECTION}/${id}`;
  if (snapshot.exists !== true || snapshot.ref?.path !== path || snapshot.ref?.id !== id) fail("unexpected_inbox_document_path");
  const claimedId = event.params?.eventId;
  if (claimedId !== undefined && claimedId !== id) fail("conflicting_inbox_document_id");
  // Some transports omit the document extension; the SDK snapshot remains
  // authoritative. If extensions are present they must describe the same row.
  if (event.document !== undefined && event.document !== path) fail("conflicting_firestore_document");
  if (event.subject !== undefined && event.subject !== `documents/${path}`) fail("conflicting_firestore_subject");
  return id;
}

function safeErrorCode(error) { return /^[a-z0-9_]{1,100}$/.test(error?.code || "") ? error.code : "trigger_unhandled_error"; }

async function recordTriggerFailure(db, error, { now = Date.now } = {}) {
  const ref = db.collection("opsSlackEventLocks").doc("_health_trigger");
  return db.runTransaction(async transaction => {
    const snapshot = await transaction.get(ref);
    const previous = snapshot.exists ? snapshot.data() : {};
    const at = Number(now());
    transaction.set(ref, {
      version: "2026-09-22.1", source: "trigger", sinceMs: Number(previous.sinceMs || at),
      updatedAtMs: at, lastFailureAtMs: at, lastState: "retry", lastCode: safeErrorCode(error),
      counts: { ...(previous.counts || {}), failure: Number(previous.counts?.failure || 0) + 1 },
    }, { merge: true });
    return { recorded: true };
  });
}

function createInboxTrigger({ processEvent, recordFailure, logger = console, projectId = PROJECT_ID, databaseId = DATABASE_ID } = {}) {
  if (typeof processEvent !== "function") fail("missing_inbox_processor");
  return async event => {
    let id;
    try {
      id = extractInboxEventId(event, { projectId, databaseId });
      const invocationId = typeof event.id === "string" && /^[A-Za-z0-9._:-]{1,200}$/.test(event.id) ? event.id : "";
      const result = await processEvent(id, { source: "trigger", invocationId });
      logger.info?.("ops_slack_trigger_result", { inboxEventId: id, invocationId, state: result?.state || "unknown", reason: result?.reason || result?.code || "" });
      return result;
    }
    catch (error) {
      // Never log the raw CloudEvent: it includes the original private message.
      logger.error?.("ops_slack_trigger_failed", { code: safeErrorCode(error), hasSnapshot: Boolean(event?.data), hasParams: Boolean(event?.params?.eventId) });
      if (typeof recordFailure === "function") {
        try { await recordFailure(error); }
        catch (_) { logger.warn?.("ops_slack_trigger_health_unavailable", { code: "health_write_failed" }); }
      }
      throw error;
    }
  };
}

module.exports = { extractInboxEventId, createInboxTrigger, recordTriggerFailure, PROJECT_ID, DATABASE_ID, COLLECTION, CREATED_TYPE };
