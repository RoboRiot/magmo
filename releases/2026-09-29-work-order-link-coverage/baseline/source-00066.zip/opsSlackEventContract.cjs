"use strict";

const crypto = require("node:crypto");

// Pure boundary contract; no Slack client, database, command execution or AI.
// Signature: https://docs.slack.dev/authentication/verifying-requests-from-slack/
// Envelope: https://docs.slack.dev/apis/events-api/
// Edits: https://docs.slack.dev/reference/events/message/message_changed/
const DISPATCH_CHANNEL_ID = "C07EPLKV9JT";
const MAX_RAW_BODY_BYTES = 1024 * 1024;
const MAX_TEXT_LENGTH = 16000;
const MAX_EVENT_ID_LENGTH = 128;
const SLACK_TS = /^\d{10,12}\.\d{6}$/;
const SLACK_USER = /^[UW][A-Z0-9]{2,63}$/;

class SlackEventContractError extends Error {
  constructor(code, statusCode = 400) {
    super(code);
    this.name = "SlackEventContractError";
    this.code = code;
    this.statusCode = statusCode;
  }
}
const fail = (code, statusCode) => { throw new SlackEventContractError(code, statusCode); };
const object = value => value !== null && typeof value === "object" && !Array.isArray(value);
const boundedString = (value, limit) => typeof value === "string"
  ? value.replace(/\r\n?/g, "\n").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").slice(0, limit)
  : "";

function normalizeSlackEventConfig(input = {}) {
  if (!object(input)) fail("invalid_slack_event_config", 503);
  const { signingSecret, teamId, appId } = input;
  if (typeof signingSecret !== "string" || !signingSecret.trim()) fail("missing_slack_signing_secret", 503);
  if (typeof teamId !== "string" || !/^T[A-Z0-9]{2,63}$/.test(teamId)) fail("missing_slack_team_id", 503);
  if (typeof appId !== "string" || !/^A[A-Z0-9]{2,63}$/.test(appId)) fail("missing_slack_app_id", 503);
  if (input.channelId !== undefined && input.channelId !== DISPATCH_CHANNEL_ID) fail("invalid_dispatch_channel", 503);
  return Object.freeze({ signingSecret, teamId, appId, channelId: DISPATCH_CHANNEL_ID });
}

function headerValue(headers, name) {
  if (!headers || typeof headers !== "object") return "";
  const entries = typeof headers.entries === "function" ? [...headers.entries()] : Object.entries(headers);
  const found = entries.filter(([key]) => key.toLowerCase() === name);
  return found.length === 1 && typeof found[0][1] === "string" ? found[0][1] : "";
}

function rawBodyBuffer(rawBody) {
  return Buffer.isBuffer(rawBody) ? rawBody : typeof rawBody === "string" ? Buffer.from(rawBody, "utf8") : null;
}

function verifySlackEventSignature({ rawBody, headers, signingSecret, nowMs = Date.now() } = {}) {
  const body = rawBodyBuffer(rawBody);
  if (!body || body.length > MAX_RAW_BODY_BYTES || typeof signingSecret !== "string" || !signingSecret.trim()) return false;
  const timestamp = headerValue(headers, "x-slack-request-timestamp");
  const signature = headerValue(headers, "x-slack-signature");
  if (!/^\d{10,12}$/.test(timestamp) || !/^v0=[a-f0-9]{64}$/.test(signature) || !Number.isFinite(nowMs)) return false;
  if (Math.abs(nowMs / 1000 - Number(timestamp)) > 300) return false;
  const calculated = "v0=" + crypto.createHmac("sha256", signingSecret)
    .update(`v0:${timestamp}:`, "utf8").update(body).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(signature, "ascii"), Buffer.from(calculated, "ascii"));
}

function slackTimestamp(value) {
  if (typeof value !== "string" || !SLACK_TS.test(value)) fail("invalid_slack_timestamp");
  return value;
}
function compareSlackTimestamps(left, right) {
  const a = BigInt(slackTimestamp(left).replace(".", ""));
  const b = BigInt(slackTimestamp(right).replace(".", ""));
  return a < b ? -1 : a > b ? 1 : 0;
}
function humanSender(value) {
  if (typeof value !== "string" || !SLACK_USER.test(value) || value === "USLACKBOT") fail("invalid_slack_sender");
  return value;
}

// Do not append link-unfurl/attachment text to the human author's text. That
// content can be written by another person. Quotes/code retain their markers.
function normalizeSlackMessageContent(message = {}) {
  let truncated = false, remaining = MAX_TEXT_LENGTH, nodes = 0;
  const visited = new WeakSet();
  function take(value) {
    const full = boundedString(value, MAX_TEXT_LENGTH + 1);
    const part = full.slice(0, remaining);
    if (part.length < full.length) truncated = true;
    remaining -= part.length;
    return part;
  }
  function render(node, depth = 0) {
    if (!object(node) || depth > 12 || ++nodes > 400 || visited.has(node)) { truncated = true; return ""; }
    visited.add(node);
    if (remaining <= 0) { truncated = true; return ""; }
    if (node.type === "text" || node.type === "plain_text" || node.type === "mrkdwn") return take(node.text);
    if (node.type === "user") return SLACK_USER.test(node.user_id || "") ? take(`<@${node.user_id}>`) : "";
    if (node.type === "channel") return /^C[A-Z0-9]{2,63}$/.test(node.channel_id || "") ? take(`<#${node.channel_id}>`) : "";
    if (node.type === "emoji") return typeof node.name === "string" && /^[a-zA-Z0-9_+-]{1,80}$/.test(node.name) ? take(`:${node.name}:`) : "";
    if (node.type === "link") {
      const url = boundedString(node.url, 2000), label = boundedString(node.text, 2000);
      return /^https?:\/\//i.test(url) ? take(label ? `<${url}|${label}>` : `<${url}>`) : take(label);
    }
    if (node.type === "section") return object(node.text) ? render(node.text, depth + 1) : "";
    if (!["rich_text", "rich_text_section", "rich_text_list", "rich_text_quote", "rich_text_preformatted"].includes(node.type)) return "";
    const children = Array.isArray(node.elements) ? node.elements.slice(0, 100) : [];
    if (Array.isArray(node.elements) && node.elements.length > 100) truncated = true;
    const rendered = children.map(child => render(child, depth + 1)).filter(Boolean).join(["rich_text", "rich_text_list"].includes(node.type) ? "\n" : "");
    if (node.type === "rich_text_quote") return rendered.split("\n").map(line => `> ${line}`).join("\n");
    if (node.type === "rich_text_preformatted") return "```\n" + rendered + "\n```";
    return rendered;
  }
  const text = typeof message.text === "string" && message.text.trim()
    ? take(message.text)
    : (Array.isArray(message.blocks) ? message.blocks.slice(0, 50).map(block => render(block)).filter(Boolean).join("\n") : "");
  if (Array.isArray(message.blocks) && message.blocks.length > 50) truncated = true;
  const attachments = (Array.isArray(message.attachments) ? message.attachments : []).slice(0, 10).filter(object).map(row => ({
    title: boundedString(row.title, 300), text: boundedString(row.text, 1000), fallback: boundedString(row.fallback, 1000),
    authorName: boundedString(row.author_name, 160), untrustedContext: true,
  }));
  const files = (Array.isArray(message.files) ? message.files : []).slice(0, 20).filter(row => object(row) && typeof row.id === "string" && /^F[A-Z0-9]{2,63}$/.test(row.id)).map(row => ({
    id: row.id, name: boundedString(row.name, 300), title: boundedString(row.title, 300), mimetype: boundedString(row.mimetype, 160),
  }));
  return { text: text.slice(0, MAX_TEXT_LENGTH).trim(), textTruncated: truncated || text.length > MAX_TEXT_LENGTH, attachments, files };
}

function pythonCommand(text) {
  // All bang commands belong to Python, including commands added there later.
  const command = text.match(/^[ \t]*(?:<@[UW][A-Z0-9]+>[ \t]*)?[`*_~]*!([a-z][a-z0-9_-]{0,39})(?=[\s`*_~]|$)/im);
  if (command) return "!" + command[1].toLowerCase();
  return /^\s*-help\s*$/i.test(text) ? "-help" : "";
}

function normalizeSlackEventPayload(payload, inputConfig) {
  const config = normalizeSlackEventConfig(inputConfig);
  if (!object(payload)) fail("invalid_slack_payload");
  if (payload.type === "url_verification") {
    // Slack's signed challenge schema normally omits team_id/api_app_id.
    if (payload.team_id !== undefined && payload.team_id !== config.teamId) fail("slack_team_mismatch", 403);
    if (payload.api_app_id !== undefined && payload.api_app_id !== config.appId) fail("slack_app_mismatch", 403);
    if (typeof payload.challenge !== "string" || !payload.challenge.length || payload.challenge.length > 1000 || /[\u0000-\u001f]/.test(payload.challenge)) fail("invalid_slack_challenge");
    return { kind: "challenge", challenge: payload.challenge, teamId: config.teamId, appId: config.appId };
  }
  if (payload.type !== "event_callback") return { kind: "ignored", reason: "not_event_callback" };
  if (payload.team_id !== config.teamId) fail("slack_team_mismatch", 403);
  if (payload.api_app_id !== config.appId) fail("slack_app_mismatch", 403);
  if (typeof payload.event_id !== "string" || !/^Ev[A-Za-z0-9]+$/.test(payload.event_id) || payload.event_id.length > MAX_EVENT_ID_LENGTH) fail("invalid_slack_event_id");
  const base = { eventId: payload.event_id, teamId: config.teamId, appId: config.appId };
  const ignored = reason => ({ ...base, kind: "ignored", reason });
  const event = payload.event;
  if (!object(event)) fail("invalid_slack_event");
  if (event.type !== "message") return ignored("not_message");
  // Preserve the pre-existing, explicit DM help request without widening the
  // evidence channel or returning report-command ownership to the website.
  if (event.channel_type === "im" && typeof event.channel === "string" && /^D[A-Z0-9]{2,63}$/.test(event.channel)
      && !event.subtype && !event.edited && !event.bot_id && !event.app_id && !event.bot_profile
      && event.user !== "USLACKBOT" && typeof event.text === "string" && event.text.trim().toLowerCase() === "-help") {
    const senderId = humanSender(event.user), messageTs = slackTimestamp(event.ts);
    return { ...base, kind: "help", channel: event.channel, senderId, messageTs,
      text: "-help", edited: false, processEvidence: false };
  }
  if (event.channel !== DISPATCH_CHANNEL_ID) return ignored("not_dispatch_channel");
  const edited = event.subtype === "message_changed";
  if (event.subtype && !["message_changed", "file_share", "thread_broadcast"].includes(event.subtype)) return ignored(event.subtype === "bot_message" ? "bot_message" : "unsupported_message_subtype");
  const message = edited ? event.message : event;
  if (!object(message)) fail("invalid_slack_message");
  if (event.bot_id || event.app_id || message.bot_id || message.app_id || message.bot_profile || message.subtype === "bot_message" || message.user === "USLACKBOT") return ignored("bot_message");
  if (message.subtype && !["message_changed", "file_share", "thread_broadcast"].includes(message.subtype)) return ignored("unsupported_message_subtype");
  if (message.channel !== undefined && message.channel !== event.channel) fail("slack_message_identity_conflict");
  if (edited && (!object(message.edited) || !message.edited.ts)) return ignored("metadata_only_change");
  const senderId = humanSender(message.user);
  const messageTs = slackTimestamp(message.ts);
  const threadTs = slackTimestamp(message.thread_ts === undefined ? messageTs : message.thread_ts);
  if (compareSlackTimestamps(threadTs, messageTs) > 0) fail("invalid_slack_thread_timestamp");
  if (edited && event.thread_ts !== undefined && event.thread_ts !== threadTs) fail("slack_message_identity_conflict");
  const versionTs = edited ? slackTimestamp(message.edited.ts) : messageTs;
  if (compareSlackTimestamps(versionTs, messageTs) < 0) fail("invalid_slack_edit_timestamp");
  const editorId = edited && message.edited.user !== undefined ? humanSender(message.edited.user) : "";
  const content = normalizeSlackMessageContent(message);
  if (edited && object(event.previous_message)) {
    const previous = event.previous_message;
    if ((previous.ts !== undefined && previous.ts !== messageTs) || (previous.user !== undefined && previous.user !== senderId) || (previous.thread_ts !== undefined && previous.thread_ts !== threadTs)) fail("slack_message_identity_conflict");
    const oldContent = normalizeSlackMessageContent(previous);
    if (oldContent.text === content.text && JSON.stringify(oldContent.files) === JSON.stringify(content.files)) return ignored("metadata_only_change");
  }
  const command = pythonCommand(content.text);
  const result = { ...base, kind: command ? "command" : "message", channel: DISPATCH_CHANNEL_ID, threadTs, messageTs, versionTs, senderId, ...content,
    edited, editorId, editedByAnotherUser: Boolean(editorId && editorId !== senderId), isRoot: messageTs === threadTs };
  if (command) return { ...result, command, commandOwner: "python", processEvidence: false };
  if (!content.text && !content.files.length && !edited) return ignored("empty_message");
  return { ...result, processEvidence: true };
}

function parseSlackEventRequest({ rawBody, headers, config, nowMs = Date.now() } = {}) {
  const normalizedConfig = normalizeSlackEventConfig(config);
  const body = rawBodyBuffer(rawBody);
  if (!body) fail("raw_slack_body_required");
  if (body.length > MAX_RAW_BODY_BYTES) fail("slack_payload_too_large", 413);
  if (!verifySlackEventSignature({ rawBody: body, headers, signingSecret: normalizedConfig.signingSecret, nowMs })) fail("invalid_slack_signature", 401);
  let payload;
  try { payload = JSON.parse(body.toString("utf8")); } catch { fail("invalid_slack_json"); }
  return normalizeSlackEventPayload(payload, normalizedConfig);
}

module.exports = { DISPATCH_CHANNEL_ID, MAX_RAW_BODY_BYTES, MAX_TEXT_LENGTH, MAX_EVENT_ID_LENGTH, SlackEventContractError,
  normalizeSlackEventConfig, verifySlackEventSignature, normalizeSlackMessageContent, normalizeSlackEventPayload, parseSlackEventRequest,
  compareSlackTimestamps };
