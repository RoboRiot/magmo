"use strict";

const { createHash, randomUUID: cryptoRandomUUID } = require("node:crypto");

const INBOX_COLLECTION = "opsSlackEventInbox";
const LOCK_COLLECTION = "opsSlackEventLocks";
const THREAD_LINK_COLLECTION = "OpsSlackThreadLinks";
const WORK_ORDER_COLLECTION = "OpsWorkOrders";
const DISPATCH_CHANNEL = "C07EPLKV9JT";
const SLACK_TEAM = "T07FT07CC56";
const SLACK_APP = "A08J13AGSMD";
const INGEST_URL = "https://magmo.cloud/api/ops/ingest";
const LEASE_MS = 720000;
const INGEST_TIMEOUT_MS = 480000;
const MAX_ATTEMPTS = 8;
const RETRY_BASE_MS = 30000;
const SWEEP_LIMIT = 4;
const RECEIPT_GRACE_MS = 300000;
const HEALTH_DOC_PREFIX = "_health_";
const TERMINAL_STATES = new Set(["completed", "ignored", "dead_letter", "shadow"]);

class InboxError extends Error {
  constructor(code, statusCode = 400) {
    super(code);
    this.name = "OpsSlackInboxError";
    this.code = code;
    this.statusCode = statusCode;
  }
}

function digest(value) { return createHash("sha256").update(value).digest("hex"); }
function clean(value) { return typeof value === "string" ? value.trim() : ""; }
function redactTerminalEvent(event) {
  // The inbox is a delivery queue, not a second permanent Slack transcript.
  // Preserve receipt identity/hash-based dedupe while the authoritative Ops log
  // follows its existing Closed-only retention policy.
  return { ...event, text: "", attachments: [], files: [], payloadRedacted: true };
}
function modeFor(env) {
  const value = clean(env.OPS_SLACK_EVENTS_MODE).toLowerCase();
  return value === "shadow" || value === "active" ? value : "disabled";
}

// Receive only the signature-verified, normalized contract. Keep validation here
// too so a trigger or future caller cannot route an arbitrary Slack identity.
function normalizeEvent(input = {}) {
  const event = {
    kind: clean(input.kind),
    eventId: clean(input.eventId), teamId: clean(input.teamId), appId: clean(input.appId),
    channel: clean(input.channel), threadTs: clean(input.threadTs),
    messageTs: clean(input.messageTs), senderId: clean(input.senderId),
    text: typeof input.text === "string" ? input.text : "",
    versionTs: clean(input.versionTs || input.messageTs),
    edited: input.edited === true, editorId: clean(input.editorId),
    editedByAnotherUser: input.editedByAnotherUser === true,
    isRoot: input.isRoot === true, textTruncated: input.textTruncated === true,
    attachments: (Array.isArray(input.attachments) ? input.attachments : []).slice(0, 20).map(item => ({
      title: clean(item?.title).slice(0, 1000), text: clean(item?.text).slice(0, 6000),
      fallback: clean(item?.fallback).slice(0, 1000), authorName: clean(item?.authorName).slice(0, 200), untrustedContext: true,
    })),
    files: (Array.isArray(input.files) ? input.files : []).slice(0, 20).map(item => ({
      id: clean(item?.id).slice(0, 100), name: clean(item?.name).slice(0, 500),
      title: clean(item?.title).slice(0, 500), mimetype: clean(item?.mimetype).slice(0, 150),
    })),
  };
  if (!/^[A-Za-z0-9_-]{1,180}$/.test(event.eventId)) throw new InboxError("invalid_event_id");
  if (event.teamId !== SLACK_TEAM || event.appId !== SLACK_APP) throw new InboxError("unexpected_slack_identity", 403);
  if (event.channel !== DISPATCH_CHANNEL) throw new InboxError("unexpected_slack_channel", 403);
  for (const key of ["threadTs", "messageTs", "versionTs"]) {
    if (!/^\d{8,}\.\d{1,9}$/.test(event[key])) throw new InboxError("invalid_slack_timestamp");
  }
  if (event.text.length > 40000) throw new InboxError("message_too_large", 413);
  return event;
}

function createOpsSlackInbox({ db, fetch: fetchImpl = globalThis.fetch, env = process.env, now = Date.now, randomUUID = cryptoRandomUUID } = {}) {
  if (!db || typeof db.runTransaction !== "function") throw new InboxError("missing_database", 503);
  const clock = () => Number(now());
  const eventRef = id => db.collection(INBOX_COLLECTION).doc(id);
  const lockRef = event => db.collection(LOCK_COLLECTION).doc(digest(`${event.channel}:${event.threadTs}`));
  const configured = () => clean(env.OPS_SLACK_EVENTS_TEAM_ID) === SLACK_TEAM && clean(env.OPS_SLACK_EVENTS_APP_ID) === SLACK_APP;
  const userCache = new Map();
  const userLookups = new Map();

  async function timedFetch(url, options, timeoutMs) {
    if (timeoutMs <= 1000) throw new InboxError("processing_deadline", 503);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    timer.unref?.();
    try {
      const response = await fetchImpl(url, { ...options, signal: controller.signal });
      return { response, body: await response.json() };
    } finally { clearTimeout(timer); }
  }

  async function resolveUser(id, deadlineAt) {
    const cached = userCache.get(id);
    if (cached && cached.untilMs > clock()) return cached.person;
    if (userLookups.has(id)) return userLookups.get(id);
    const lookup = (async () => {
      const token = clean(env.SLACK_BOT_TOKEN);
      if (!token) {
        const names = new Map(String(env.SLACK_USER_NAME_MAP || "").split(",").map(pair => {
          const separator = pair.indexOf("=");
          return separator > 0 ? [pair.slice(0, separator).trim(), pair.slice(separator + 1).trim()] : ["", ""];
        }));
        const name = names.get(id);
        if (!name || name === id) throw new InboxError("slack_user_lookup_unavailable", 503);
        return { id, name: name.slice(0, 120), isBot: false };
      }
      const { response, body } = await timedFetch(`https://slack.com/api/users.info?user=${encodeURIComponent(id)}`, {
        method: "GET", headers: { Authorization: `Bearer ${token}` },
      }, Math.min(10000, deadlineAt - clock()));
      const user = body?.user;
      if (!response.ok || body?.ok !== true || user?.id !== id) throw new InboxError("slack_user_lookup_failed", 503);
      const name = clean(user.real_name || user.profile?.real_name || user.profile?.display_name);
      if (!name || name === id) throw new InboxError("slack_user_name_missing", 503);
      return { id, name: name.slice(0, 120), isBot: user.is_bot === true || user.is_app_user === true };
    })();
    userLookups.set(id, lookup);
    try {
      const person = await lookup;
      userCache.set(id, { person, untilMs: clock() + 3600000 });
      return person;
    } finally { userLookups.delete(id); }
  }

  async function receiveNormalized(input) {
    const mode = modeFor(env);
    if (mode === "disabled") return { ok: true, stored: false, reason: "disabled" };
    if (!configured()) throw new InboxError("slack_events_not_configured", 503);
    if (input?.kind !== "message" || input.processEvidence === false) {
      return { ok: true, stored: false, reason: input?.kind === "command" ? "command" : "ignored" };
    }
    const event = normalizeEvent(input);
    if (input.botId || input.bot_id || input.bot || !/^[UW][A-Z0-9]{2,63}$/.test(event.senderId)) {
      return { ok: true, stored: false, reason: "non_human" };
    }
    if (/^\s*!\S+/.test(event.text)) return { ok: true, stored: false, reason: "command" };
    const bodyHash = digest(JSON.stringify(event));
    const ref = eventRef(event.eventId);
    return db.runTransaction(async transaction => {
      const snapshot = await transaction.get(ref);
      if (snapshot.exists) {
        if (snapshot.data().bodyHash !== bodyHash) throw new InboxError("event_id_collision", 409);
        return { ok: true, stored: false, duplicate: true, eventId: event.eventId };
      }
      const receivedAtMs = clock();
      const initialState = event.editedByAnotherUser ? "dead_letter" : mode === "shadow" ? "shadow" : "pending";
      const threadKey = digest(`${event.channel}:${event.threadTs}`);
      transaction.set(ref, {
        event: TERMINAL_STATES.has(initialState) ? redactTerminalEvent(event) : event,
        bodyHash, threadKey, pendingThreadKey: initialState === "pending" ? threadKey : null, state: initialState,
        attempts: 0, receivedAtMs, updatedAtMs: receivedAtMs,
        dueAtMs: initialState === "pending" ? receivedAtMs : null,
        leaseToken: "", leaseUntilMs: 0, lastCode: event.editedByAnotherUser ? "cross_user_edit_review" : "", workOrderId: "",
      });
      return { ok: true, stored: true, eventId: event.eventId, state: initialState };
    });
  }

  async function claim(id, attribution) {
    const ref = eventRef(id);
    return db.runTransaction(async transaction => {
      const snapshot = await transaction.get(ref);
      if (!snapshot.exists) return { claimed: false, reason: "not_found" };
      const saved = snapshot.data();
      if (TERMINAL_STATES.has(saved.state) || saved.state === "needs_link") return { claimed: false, reason: saved.state };
      const at = clock();
      if (Number(saved.dueAtMs || 0) > at || (saved.state === "processing" && Number(saved.leaseUntilMs || 0) > at)) {
        return { claimed: false, reason: "not_due" };
      }
      const event = normalizeEvent(saved.event);
      if (event.kind !== "message" || event.editedByAnotherUser || /^\s*!\S+/.test(event.text) || !/^[UW][A-Z0-9]{2,63}$/.test(event.senderId)) {
        transaction.set(ref, { event: redactTerminalEvent(event), state: "dead_letter", pendingThreadKey: null, dueAtMs: null, updatedAtMs: at, lastCode: "invalid_stored_event" }, { merge: true });
        return { claimed: false, reason: "dead_letter" };
      }
      const threadKey = digest(`${event.channel}:${event.threadTs}`);
      const threadRef = lockRef(event);
      const lock = await transaction.get(threadRef);
      if (lock.exists && Number(lock.data().leaseUntilMs || 0) > at) {
        transaction.set(ref, { state: "retry", pendingThreadKey: threadKey, dueAtMs: Math.min(Number(lock.data().leaseUntilMs), at + 15000), updatedAtMs: at, lastCode: "thread_busy" }, { merge: true });
        return { claimed: false, reason: "thread_busy" };
      }
      // Scan only outstanding work, not the entire completed thread history.
      const siblings = await transaction.get(db.collection(INBOX_COLLECTION).where("pendingThreadKey", "==", threadKey));
      const earlierDue = siblings.docs.some(document => {
        if (document.id === id) return false;
        const other = document.data();
        if (TERMINAL_STATES.has(other.state) || Number(other.dueAtMs || Infinity) > at) return false;
        const otherTs = Number(other.event?.versionTs || other.event?.messageTs);
        const thisTs = Number(event.versionTs || event.messageTs);
        return otherTs < thisTs || (otherTs === thisTs && document.id.localeCompare(id) < 0);
      });
      if (earlierDue) {
        transaction.set(ref, { state: "retry", pendingThreadKey: threadKey, dueAtMs: at + 15000, updatedAtMs: at, lastCode: "earlier_thread_event" }, { merge: true });
        return { claimed: false, reason: "earlier_thread_event" };
      }
      const attempts = Number(saved.attempts || 0) + 1;
      if (attempts > MAX_ATTEMPTS) {
        transaction.set(ref, { event: redactTerminalEvent(event), state: "dead_letter", pendingThreadKey: null, dueAtMs: null, updatedAtMs: at, lastCode: "attempts_exhausted" }, { merge: true });
        return { claimed: false, reason: "dead_letter" };
      }
      const leaseToken = randomUUID();
      const leaseUntilMs = at + LEASE_MS;
      transaction.set(threadRef, { eventId: id, leaseToken, leaseUntilMs, updatedAtMs: at });
      transaction.set(ref, { state: "processing", pendingThreadKey: threadKey, attempts, leaseToken, leaseUntilMs, dueAtMs: leaseUntilMs, updatedAtMs: at, lastCode: "",
        firstProcessingSource: saved.firstProcessingSource || attribution.source,
        firstProcessingAtMs: saved.firstProcessingAtMs || at,
        processingSource: attribution.source, processingInvocationId: attribution.invocationId, processingStartedAtMs: at,
      }, { merge: true });
      return { claimed: true, event, attempts, leaseToken, ref, threadRef, receivedAtMs: Number(saved.receivedAtMs || at), attribution };
    });
  }

  async function finish(claimed, { state, code = "", workOrderId = "", retryAfterMs = 0 }) {
    return db.runTransaction(async transaction => {
      const healthRef = db.collection(LOCK_COLLECTION).doc(`${HEALTH_DOC_PREFIX}${claimed.attribution.source}`);
      const [snapshot, lock, healthSnapshot] = await Promise.all([transaction.get(claimed.ref), transaction.get(claimed.threadRef), transaction.get(healthRef)]);
      if (!snapshot.exists || snapshot.data().leaseToken !== claimed.leaseToken) return { state: "superseded" };
      const at = clock();
      const finalState = state === "retry" && claimed.attempts >= MAX_ATTEMPTS ? "dead_letter" : state;
      const backoff = Math.min(3600000, RETRY_BASE_MS * 2 ** Math.min(claimed.attempts - 1, 7));
      const dueAtMs = code === "work_order_not_found"
        ? Math.min(at + backoff, claimed.receivedAtMs + RECEIPT_GRACE_MS)
        : at + Math.max(backoff, retryAfterMs);
      transaction.set(claimed.ref, {
        ...(TERMINAL_STATES.has(finalState) ? { event: redactTerminalEvent(claimed.event) } : {}),
        state: finalState, lastCode: code, updatedAtMs: at, workOrderId,
        pendingThreadKey: TERMINAL_STATES.has(finalState) || finalState === "needs_link" ? null : digest(`${claimed.event.channel}:${claimed.event.threadTs}`),
        dueAtMs: finalState === "retry" ? dueAtMs : null,
        ...(finalState === "completed" ? { completedAtMs: at, completedBy: claimed.attribution.source } : {}),
        ...(finalState === "needs_link" ? { needsLinkAtMs: at } : {}),
        leaseToken: "", leaseUntilMs: 0,
      }, { merge: true });
      if (lock.exists && lock.data().leaseToken === claimed.leaseToken) {
        transaction.set(claimed.threadRef, { leaseToken: "", leaseUntilMs: 0, updatedAtMs: at }, { merge: true });
      }
      const health = healthSnapshot.exists ? healthSnapshot.data() : {};
      transaction.set(healthRef, {
        version: "2026-09-22.1", source: claimed.attribution.source,
        sinceMs: Number(health.sinceMs || at), updatedAtMs: at, lastState: finalState, lastCode: code,
        lastProcessingStartedAtMs: claimed.attribution.startedAtMs || at,
        lastCompletedAtMs: finalState === "completed" ? at : Number(health.lastCompletedAtMs || 0),
        lastFailureAtMs: ["retry", "dead_letter"].includes(finalState) ? at : Number(health.lastFailureAtMs || 0),
        counts: { ...(health.counts || {}), [finalState]: Number(health.counts?.[finalState] || 0) + 1 },
      }, { merge: true });
      return { state: finalState, code, workOrderId };
    });
  }

  async function processEvent(id, context = {}) {
    const deadlineAt = clock() + INGEST_TIMEOUT_MS;
    if (modeFor(env) !== "active") return { state: "skipped", reason: modeFor(env) };
    if (!configured()) return { state: "skipped", reason: "slack_events_not_configured" };
    if (!/^[A-Za-z0-9_-]{1,180}$/.test(String(id || ""))) throw new InboxError("invalid_event_id");
    const attribution = {
      source: ["trigger", "sweep", "admin"].includes(context.source) ? context.source : "direct",
      invocationId: typeof context.invocationId === "string" && /^[A-Za-z0-9._:-]{1,200}$/.test(context.invocationId) ? context.invocationId : "",
      startedAtMs: clock(),
    };
    const claimed = await claim(id, attribution);
    if (!claimed.claimed) return { state: "skipped", reason: claimed.reason };
    let workOrderId = "";
    try {
      const roots = await db.collection(WORK_ORDER_COLLECTION).where("slackThreadTs", "==", claimed.event.threadTs).get();
      const matches = roots.docs.filter(document => document.data().slackChannel === DISPATCH_CHANNEL);
      let selected = matches[0], slackThreadLinkId = "";
      if (matches.length > 1) return finish(claimed, { state: "dead_letter", code: "ambiguous_dispatch_receipt" });
      if (!selected) {
        const linkId = digest(`${claimed.event.channel}:${claimed.event.threadTs}`);
        const mapping = await db.collection(THREAD_LINK_COLLECTION).doc(linkId).get();
        if (mapping.exists && mapping.data().active === true) {
          const link = mapping.data();
          if (link.channel !== DISPATCH_CHANNEL || link.threadTs !== claimed.event.threadTs || !/^[A-Za-z0-9_-]{1,180}$/.test(link.workOrderId || "")) {
            return finish(claimed, { state: "dead_letter", code: "invalid_thread_link" });
          }
          const linkedOrder = await db.collection(WORK_ORDER_COLLECTION).doc(link.workOrderId).get();
          if (linkedOrder.exists) { selected = linkedOrder; slackThreadLinkId = linkId; }
        }
      }
      if (!selected) return finish(claimed, {
        state: clock() >= claimed.receivedAtMs + RECEIPT_GRACE_MS ? "needs_link" : "retry",
        code: "work_order_not_found",
      });
      const workOrder = selected.data();
      workOrderId = selected.id;
      if (workOrder.deletedAt || workOrder.deleted === true || workOrder.isDeleted === true) {
        return finish(claimed, { state: "ignored", code: "deleted", workOrderId });
      }
      if (clean(workOrder.workflowStatus || workOrder.workflowStage || workOrder.status).toLowerCase() === "closed") {
        return finish(claimed, { state: "ignored", code: "closed", workOrderId });
      }
      if (modeFor(env) !== "active") return finish(claimed, { state: "retry", code: "disabled_during_processing", workOrderId });
      const secret = clean(env.OPS_INGEST_SECRET);
      if (!secret) return finish(claimed, { state: "retry", code: "ingest_not_configured", workOrderId });
      const event = claimed.event;
      const sender = await resolveUser(event.senderId, deadlineAt);
      if (sender.isBot) return finish(claimed, { state: "ignored", code: "non_human", workOrderId });
      const mentionIds = [...new Set([...event.text.matchAll(/<@([UW][A-Z0-9]{2,63})(?:\|[^>]+)?>/g)].map(match => match[1]))]
        .filter(id => id !== sender.id).slice(0, 5);
      const mentionedUsers = await Promise.all(mentionIds.map(id => resolveUser(id, deadlineAt)));
      const payload = {
        eventType: "message.created", workOrderId,
        slackChannel: event.channel, slackThreadTs: event.threadTs, slackTs: event.messageTs,
        senderId: event.senderId, senderName: sender.name, sender: { id: sender.id, name: sender.name }, text: event.text,
        candidates: mentionedUsers.filter(person => !person.isBot).map(person => ({ id: person.id, name: person.name })),
        slackEventId: event.eventId, slackVersionTs: event.versionTs,
        ...(slackThreadLinkId ? { slackThreadLinkId } : {}),
        ...(event.edited ? { slackEditedTs: event.versionTs } : {}),
        slackEventSource: "events_api", files: event.files, attachments: event.attachments,
        source: { channel: event.channel, threadTs: event.threadTs, sourceType: "slack_events", automation: "magmo-slack-events" },
      };
      if (modeFor(env) !== "active") return finish(claimed, { state: "retry", code: "disabled_during_processing", workOrderId });
      const { response, body } = await timedFetch(INGEST_URL, {
        method: "POST", headers: { "Content-Type": "application/json", "x-ops-ingest-secret": secret }, body: JSON.stringify(payload),
      }, deadlineAt - clock() - 1000);
      const code = clean(body?.code || body?.reason).toLowerCase();
      const busy = body?.retryable === true || /(?:in_progress|processing|busy|stale_lease)/.test(code);
      const ambiguousDuplicate = body?.accepted === false && code === "duplicate" &&
        !["completed", "not_needed"].includes(body?.analysisStatus) && body?.analyzed !== true;
      if (response.ok && body?.ok === true && !busy && !ambiguousDuplicate) {
        return finish(claimed, { state: body.reason === "closed" ? "ignored" : "completed", code: body.reason === "closed" ? "closed" : "ingested", workOrderId });
      }
      const httpStatus = Number(response.status || 0);
      const retryable = busy || ambiguousDuplicate || httpStatus === 429 || httpStatus >= 500 || [401, 403, 404, 408, 409].includes(httpStatus);
      const retryAfterSeconds = Number(response.headers?.get?.("retry-after"));
      return finish(claimed, {
        state: retryable ? "retry" : "dead_letter", workOrderId,
        code: busy ? "ingest_busy" : ambiguousDuplicate ? "duplicate_state_unconfirmed" : `ingest_http_${httpStatus || "invalid"}`,
        retryAfterMs: Number.isFinite(retryAfterSeconds) ? Math.min(3600000, Math.max(0, retryAfterSeconds * 1000)) : 0,
      });
    } catch (_) {
      // Never store upstream exception messages: they may contain credentials,
      // URLs, user text, SDK internals, or an entire authenticated request.
      return finish(claimed, { state: "retry", code: "processing_failed", workOrderId });
    }
  }

  async function sweep({ limit = SWEEP_LIMIT } = {}) {
    if (modeFor(env) !== "active") return { processed: 0, reason: modeFor(env), results: [] };
    const batchLimit = Math.max(1, Math.min(SWEEP_LIMIT, Math.floor(Number(limit) || SWEEP_LIMIT)));
    const due = await db.collection(INBOX_COLLECTION).where("dueAtMs", ">", 0).where("dueAtMs", "<=", clock()).orderBy("dueAtMs", "asc").limit(batchLimit).get();
    // Different threads can run concurrently. Per-thread leases serialize both
    // created triggers and retries; each call itself remains within runtime.
    const results = await Promise.all(due.docs.map(document => processEvent(document.id, { source: "sweep" })));
    return { processed: results.length, results };
  }

  return { receiveNormalized, processEvent, sweep };
}

module.exports = {
  createOpsSlackInbox, InboxError, normalizeEvent,
  INBOX_COLLECTION, LOCK_COLLECTION, THREAD_LINK_COLLECTION, WORK_ORDER_COLLECTION, DISPATCH_CHANNEL,
  SLACK_TEAM, SLACK_APP, INGEST_URL, LEASE_MS, INGEST_TIMEOUT_MS, MAX_ATTEMPTS, RECEIPT_GRACE_MS, HEALTH_DOC_PREFIX,
};
