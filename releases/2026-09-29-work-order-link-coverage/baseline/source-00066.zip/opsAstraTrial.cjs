"use strict";

// Shadow review only. This module deliberately has no Slack, BlueFolder,
// work-order mutation, calendar mutation, or official clock dependencies.
const crypto = require("node:crypto");
const config = require("./opsAstraTrialConfig.json");
const contract = require("./opsAstraTrialContract.cjs");
const COLLECTION = "OpsAiTrials";
const clean = (value, max = 180) => String(value || "").trim().slice(0, max);
const humanSender = sender => /^[UW][A-Z0-9]{6,}$/.test(clean(sender?.id)) && !sender.isBot && !sender.is_bot &&
  !/^(?:magmo(?:\s+recovery)?|slackbot|.*\bbot)$/i.test(clean(sender.name, 100));

function trialCapabilities(now = Date.now(), env = process.env) {
  return {
    id: config.id,
    model: "gpt-6-astra",
    mode: "shadow",
    enabled: config.enabled && env.OPS_ASTRA_TRIAL_DISABLED !== "true" &&
      now >= Date.parse(config.startsAt) && now < Date.parse(config.endsAt),
    samplePercent: config.samplePercent,
    endsAt: config.endsAt,
    maxEstimatedUsd: config.maxEstimatedUsd,
    changesLiveDecisions: false,
    changesOfficialHours: false,
    transport: "durable_shadow_queue",
    timeoutMs: config.timeoutMs,
    maxAttempts: 2,
  };
}

function eligible({ workOrder, message, accepted = true, now = Date.now(), env = process.env }) {
  if (!trialCapabilities(now, env).enabled || !accepted || !workOrder || !message) return false;
  const project = env.GCLOUD_PROJECT || env.GOOGLE_CLOUD_PROJECT || env.FIREBASE_ADMIN_PROJECT_ID;
  if (project !== config.projectId || /test|staging/i.test(env.OPS_ENVIRONMENT || "")) return false;
  if (workOrder.slackChannel !== "C07EPLKV9JT") return false;
  if (message.recoveryMode || workOrder.deletedAt || workOrder.workflowStatus === "closed") return false;
  // Exclude recovery/backfill and replay: only genuine recently posted messages.
  const ts = Number(message.slackTs);
  if (!Number.isFinite(ts) || now - ts * 1000 > 24 * 60 * 60 * 1000 || ts * 1000 > now + 60000) return false;
  if (!humanSender(message.sender) || !clean(message.text, 6000)) return false;
  return contract.cohortSelected(clean(workOrder.id || workOrder.number), config.samplePercent);
}

async function loadContext(db, workOrderId, message) {
  const ref = db.collection("OpsWorkOrders").doc(workOrderId);
  const snapshots = await Promise.all(["calendarEvents", "messages"].map(name =>
    ref.collection(name).where("slackTs", "<=", message.slackTs)
      .orderBy("slackTs", "desc").limit(40)
      .select("slackTs", "sender", "text").get()
  ));
  const byTs = new Map();
  for (const snapshot of snapshots) {
    for (const document of snapshot.docs) {
      const row = document.data();
      if (Number(row.slackTs) > Number(message.slackTs)) continue;
      if (!humanSender(row.sender) || !row.text) continue;
      if ((byTs.get(String(row.slackTs))?.text.length || 0) > clean(row.text, 6000).length) continue;
      byTs.set(String(row.slackTs), {
        id: document.id, slackTs: String(row.slackTs),
        sender: { id: clean(row.sender.id), name: clean(row.sender.name, 100) },
        text: clean(row.text, 6000),
      });
    }
  }
  byTs.set(String(message.slackTs), {
    id: clean(message.id), slackTs: String(message.slackTs),
    sender: { id: clean(message.sender.id), name: clean(message.sender.name, 100) },
    text: clean(message.text, 6000),
  });
  const ordered = [...byTs.values()].sort((a, b) => Number(b.slackTs) - Number(a.slackTs));
  const messages = [];
  let bytes = 0;
  for (const row of ordered) {
    const size = Buffer.byteLength(JSON.stringify(row), "utf8");
    if (bytes + size > 32000) break;
    messages.push(row); bytes += size;
  }
  return {
    messages: messages.reverse(),
    contextTruncated: messages.length < ordered.length || snapshots.some(snapshot => snapshot.size === 40),
  };
}

async function reserve(db, { workOrderId, slackTs, request, now, attemptKey, jobId = "", attempt = 1 }) {
  const ref = db.collection(COLLECTION).doc(config.id);
  const runId = crypto.createHash("sha256").update(attemptKey || `${workOrderId}:${slackTs}`).digest("hex");
  const runRef = ref.collection("runs").doc(runId);
  const amount = contract.estimateReservationUsd(request);
  const day = new Date(now).toISOString().slice(0, 10);
  return db.runTransaction(async tx => {
    const [stateSnapshot, runSnapshot] = await Promise.all([tx.get(ref), tx.get(runRef)]);
    const state = stateSnapshot.data() || {};
    if (runSnapshot.exists || state.enabled === false) return null;
    const committed = Number(state.committedEstimatedUsd || 0);
    const held = Number(state.reservedEstimatedUsd || 0);
    const calls = state.day === day ? Number(state.dayCalls || 0) : 0;
    if (![committed, held, calls, amount].every(value => Number.isFinite(value) && value >= 0)) return null;
    if (committed + held + amount > config.maxEstimatedUsd || calls >= config.maxCallsPerDay) return null;
    tx.set(ref, {
      ...config, enabled: true, day, dayCalls: calls + 1,
      committedEstimatedUsd: committed, reservedEstimatedUsd: held + amount,
      totalCalls: Number(state.totalCalls || 0) + 1, updatedAt: new Date(now).toISOString(),
    }, { merge: true });
    tx.set(runRef, {
      workOrderId, slackTs, model: "gpt-6-astra", mode: "shadow",
      status: "reserved", reservedEstimatedUsd: amount, jobId, attempt,
      startedAt: new Date(now).toISOString(), changesLiveDecisions: false,
    });
    return { ref, runRef, amount, runId };
  });
}

async function finish(db, reservation, result) {
  await db.runTransaction(async tx => {
    const [stateSnapshot, runSnapshot] = await Promise.all([
      tx.get(reservation.ref), tx.get(reservation.runRef),
    ]);
    if (runSnapshot.data()?.status !== "reserved") return;
    const state = stateSnapshot.data() || {};
    // A timed-out request may still be billable. Keep its full conservative
    // reservation charged; never free it and accidentally exceed the trial cap.
    const reportedCost = result.usage?.estimatedUsd;
    const charged = Number.isFinite(reportedCost) && reportedCost >= 0
      ? reportedCost
      : reservation.amount;
    const reported = Number.isFinite(reportedCost) && reportedCost >= 0;
    tx.set(reservation.ref, {
      reservedEstimatedUsd: Math.max(0, Number(state.reservedEstimatedUsd || 0) - reservation.amount),
      committedEstimatedUsd: Number(state.committedEstimatedUsd || 0) + charged,
      // These additive counters begin with this release. Existing committed
      // totals remain untouched and still govern the hard cap.
      reportedUsageEstimatedUsd: Number(state.reportedUsageEstimatedUsd || 0) + (reported ? charged : 0),
      uncertainUsageEstimatedUsd: Number(state.uncertainUsageEstimatedUsd || 0) + (reported ? 0 : charged),
      completedCalls: Number(state.completedCalls || 0) + (result.status === "completed" ? 1 : 0),
      failedCalls: Number(state.failedCalls || 0) + (result.status === "completed" ? 0 : 1),
      updatedAt: new Date().toISOString(),
    }, { merge: true });
    tx.set(reservation.runRef, {
      ...result, chargedEstimatedUsd: charged,
      chargeBasis: reported ? "reported_usage" : "uncertain_full_reservation",
      completedAt: new Date().toISOString(),
    }, { merge: true });
  });
}

async function reviewOpsAstraMessage(args, dependencies = {}) {
  if (!eligible(args)) return { skipped: true };
  const finishMarginMs = 1000;
  const deadlineAt = Number(args.deadlineAt ?? Date.now() + config.timeoutMs + 5000);
  const deadlineResult = { skipped: true, reason: "deadline_exhausted" };
  if (!Number.isFinite(deadlineAt) || deadlineAt - Date.now() <= finishMarginMs) return deadlineResult;

  const controller = new AbortController();
  let deadlineTimer;
  const remainingMs = () => deadlineAt - Date.now();
  const requireHeadroom = () => {
    if (controller.signal.aborted || remainingMs() <= finishMarginMs) {
      throw new Error("shadow_deadline_exhausted");
    }
  };

  // Awaited Firestore work cannot always be cancelled. The outer deadline still
  // releases ingestion; any late continuation is restricted to the private
  // ledger and must check the deadline before it can begin a paid model call.
  const run = async () => {
    let reservation;
    let db;
    let usage;
    const started = args.now ?? Date.now();
    const latencyStart = Date.now();
    try {
      requireHeadroom();
      db = dependencies.db || require("firebase-admin/firestore").getFirestore();
      const workOrderId = clean(args.workOrder.id || args.workOrder.number);
      const context = await loadContext(db, workOrderId, args.message);
      requireHeadroom();
      const request = contract.buildReviewRequest({
        workOrder: args.workOrder, baseline: args.baseline || args.workOrder,
        ...context, nowIso: new Date(started).toISOString(),
      });
      requireHeadroom();
      reservation = await reserve(db, { workOrderId, slackTs: String(args.message.slackTs), request, now: started });
      if (!reservation) return { skipped: true, reason: "duplicate_disabled_or_budget" };
      requireHeadroom();
      const timeoutMs = Math.min(config.timeoutMs, Math.floor(remainingMs() - finishMarginMs));
      const client = dependencies.client || new (require("openai").OpenAI)({
        apiKey: process.env.OPENAI_API_KEY, timeout: timeoutMs, maxRetries: 0,
      });
      requireHeadroom();
      const response = await client.responses.create(request, {
        timeout: Math.min(timeoutMs, Math.floor(remainingMs() - finishMarginMs)),
        maxRetries: 0, signal: controller.signal,
      });
      usage = contract.normalizeUsage(response.usage);
      if (response.status && response.status !== "completed") throw new Error("incomplete_response");
      const text = response.output_text || (response.output || []).flatMap(item => item.content || [])
        .filter(item => item.type === "output_text").map(item => item.text || "").join("");
      const review = contract.validateReview(JSON.parse(text), context.messages, args.workOrder);
      await finish(db, reservation, {
        status: "completed", usage, latencyMs: Date.now() - latencyStart,
        contextTruncated: context.contextTruncated,
        sourceMessageCount: context.messages.length,
        baseline: {
          assigneeIds: (args.baseline?.assignees || args.workOrder.assignees || []).map(person => clean(person.id)).filter(Boolean),
          participantIds: (args.baseline?.participants || args.workOrder.participants || []).map(person => clean(person.id)).filter(Boolean),
          workflowStatus: clean(args.baseline?.workflowStatus || args.workOrder.workflowStatus, 40),
        },
        review, comparison: contract.compareReview(args.baseline || args.workOrder, review),
      });
      return { reviewed: true, runId: reservation.runId };
    } catch (error) {
      if (reservation && db) await finish(db, reservation, {
        status: "failed", ...(usage ? { usage } : {}), latencyMs: Date.now() - latencyStart,
        // Never persist arbitrary SDK error strings, request bodies, or secrets.
        errorCode: Number(error?.status) ? `http_${Number(error.status)}` : "review_unavailable_or_invalid",
      }).catch(() => {});
      console.warn("[Ops][AstraTrial] shadow review unavailable; primary result preserved");
      return controller.signal.aborted || remainingMs() <= finishMarginMs
        ? deadlineResult
        : { skipped: true, reason: "review_unavailable" };
    }
  };

  const deadline = new Promise((resolve) => {
    deadlineTimer = setTimeout(() => {
      controller.abort();
      resolve(deadlineResult);
    }, Math.max(0, remainingMs()));
    deadlineTimer.unref?.();
  });
  try {
    return await Promise.race([run(), deadline]);
  } finally {
    clearTimeout(deadlineTimer);
  }
}

module.exports = { trialCapabilities, eligible, loadContext, reserve, finish, reviewOpsAstraMessage };
