"use strict";

const { createHash } = require("node:crypto");
const { INBOX_COLLECTION, LOCK_COLLECTION, THREAD_LINK_COLLECTION, WORK_ORDER_COLLECTION, DISPATCH_CHANNEL, normalizeEvent, InboxError } = require("./opsSlackInbox.cjs");
const clean = value => typeof value === "string" ? value.trim() : "";
const hash = value => createHash("sha256").update(value).digest("hex");

// This module is a server-only operation. Its API caller MUST authenticate and
// authorize an administrator, and supply that authenticated actor's ID.
// It never establishes or overwrites a work order's authoritative receipt.
// Alternate threads are linked only by an explicit audited administrator choice.
function createOpsSlackNeedsLink({ db, now = Date.now } = {}) {
  if (!db || typeof db.runTransaction !== "function") throw new InboxError("missing_database", 503);
  async function resolve(input = {}) {
    const eventId = clean(input.eventId), action = clean(input.action), actorId = clean(input.actorId), reason = clean(input.reason);
    const workOrderId = clean(input.workOrderId);
    if (!/^[A-Za-z0-9_-]{1,180}$/.test(eventId)) throw new InboxError("invalid_event_id");
    if (!["link", "ignore"].includes(action)) throw new InboxError("invalid_resolution_action");
    if (!actorId || actorId.length > 128 || /[\x00-\x1f]/.test(actorId) || !reason || reason.length > 1000) throw new InboxError("resolution_actor_and_reason_required");
    if (action === "link" && !/^[A-Za-z0-9_-]{1,180}$/.test(workOrderId)) throw new InboxError("invalid_work_order_id");
    return db.runTransaction(async transaction => {
      const ref = db.collection(INBOX_COLLECTION).doc(eventId);
      const original = await transaction.get(ref);
      if (!original.exists) throw new InboxError("inbox_event_not_found", 404);
      const saved = original.data();
      const event = normalizeEvent(saved.event);
      const threadKey = hash(`${event.channel}:${event.threadTs}`);
      if (saved.threadKey !== threadKey) throw new InboxError("invalid_thread_identity", 409);
      const at = Number(now());
      const lock = await transaction.get(db.collection(LOCK_COLLECTION).doc(threadKey));
      if (lock.exists && Number(lock.data().leaseUntilMs || 0) > at) throw new InboxError("thread_busy", 409);
      const rows = await transaction.get(db.collection(INBOX_COLLECTION).where("threadKey", "==", threadKey).limit(101));
      if (rows.docs.length > 100) throw new InboxError("resolution_thread_too_large", 409);
      const candidates = rows.docs.filter(document => {
        const row = document.data();
        return row.state === "needs_link" || (row.state === "dead_letter" && row.lastCode === "work_order_not_found");
      });
      if (!candidates.some(document => document.id === eventId)) throw new InboxError("event_not_awaiting_link", 409);
      let mappingRef, mapping;
      if (action === "link") {
        const selected = await transaction.get(db.collection(WORK_ORDER_COLLECTION).doc(workOrderId));
        if (!selected.exists) throw new InboxError("work_order_not_found", 404);
        const order = selected.data();
        if (order.deletedAt || order.deleted === true || order.isDeleted === true) throw new InboxError("work_order_deleted", 409);
        if (clean(order.workflowStatus || order.workflowStage || order.status).toLowerCase() === "closed") throw new InboxError("work_order_closed", 409);
        const receipts = await transaction.get(db.collection(WORK_ORDER_COLLECTION).where("slackThreadTs", "==", event.threadTs));
        const exact = receipts.docs.filter(document => document.data().slackChannel === DISPATCH_CHANNEL);
        if (exact.length > 1 || (exact.length === 1 && exact[0].id !== workOrderId)) throw new InboxError("authoritative_receipt_conflict", 409);
        mappingRef = db.collection(THREAD_LINK_COLLECTION).doc(threadKey);
        mapping = await transaction.get(mappingRef);
        if (mapping.exists && (mapping.data().workOrderId !== workOrderId || mapping.data().channel !== event.channel || mapping.data().threadTs !== event.threadTs)) {
          throw new InboxError("thread_link_conflict", 409);
        }
        if (candidates.some(document => document.data().event?.payloadRedacted)) throw new InboxError("source_payload_unavailable", 409);
      }
      const audit = { action, actorId, reason, workOrderId: action === "link" ? workOrderId : "", atMs: at };
      if (action === "link") transaction.set(mappingRef, {
        channel: event.channel, threadTs: event.threadTs, workOrderId, active: true,
        createdAtMs: mapping.exists ? Number(mapping.data().createdAtMs || at) : at,
        createdBy: mapping.exists ? clean(mapping.data().createdBy) || actorId : actorId,
        updatedAtMs: at, lastResolution: audit,
      }, { merge: true });
      for (const document of candidates) {
        const row = document.data();
        const source = normalizeEvent(row.event);
        if (source.channel !== event.channel || source.threadTs !== event.threadTs || source.kind !== "message" || source.editedByAnotherUser
            || !/^[UW][A-Z0-9]{2,63}$/.test(source.senderId) || /^\s*!\S+/.test(source.text)) throw new InboxError("invalid_stored_event", 409);
        transaction.set(document.ref, {
          state: action === "link" ? "retry" : "ignored",
          pendingThreadKey: action === "link" ? threadKey : null,
          dueAtMs: action === "link" ? at : null,
          ...(action === "link" ? { attempts: 0 } : { event: { ...source, text: "", files: [], attachments: [], payloadRedacted: true } }),
          updatedAtMs: at, workOrderId: action === "link" ? workOrderId : "",
          lastCode: action === "link" ? "admin_verified_receipt" : "admin_not_work_order",
          lastResolution: audit,
          resolutionHistory: [...(Array.isArray(row.resolutionHistory) ? row.resolutionHistory : []), audit].slice(-20),
        }, { merge: true });
      }
      return { ok: true, action, state: action === "link" ? "retry" : "ignored", affectedEvents: candidates.length, workOrderId: action === "link" ? workOrderId : "" };
    });
  }
  return { resolve };
}

module.exports = { createOpsSlackNeedsLink };
